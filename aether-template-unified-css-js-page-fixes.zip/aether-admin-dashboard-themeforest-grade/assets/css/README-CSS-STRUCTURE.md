# Aether CSS and JS Structure

## CSS groups

1. `assets/css/core/theme.css` — design tokens, theme variables, Bootstrap variable mapping, and auth/dashboard color aliases.
2. `assets/css/core/app.css` — application shell and reusable elements: sidebar, header, content, footer, cards, auth/utility elements, legal article elements, and final layout fixes.
3. `assets/css/pages/pages.css` — page-specific demo patterns and page packs.

Load order stays:

```html
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/core/theme.css" rel="stylesheet">
<link href="assets/css/core/app.css" rel="stylesheet">
<link href="assets/css/pages/pages.css" rel="stylesheet">
```

## JS groups

1. `assets/js/aether-dashboard.bundle.js` — dashboard/admin shell pages.
2. `assets/js/aether-auth.bundle.js` — auth, utility, error, coming soon, offline, maintenance, and under-construction pages.

Do not load the older `auth.js`, `auth-demo.js`, `theme-switcher.js`, `theme-boot.js`, `dashboard.js`, or `aether-polish.js` in production pages. They remain only as source/reference files.
