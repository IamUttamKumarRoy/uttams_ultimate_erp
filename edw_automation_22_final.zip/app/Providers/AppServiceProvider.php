<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Validator::extend('captcha', function ($attribute, $value, $parameters, $validator) {
            return strtolower($value) === Session::get('captcha');
        });

        Validator::replacer('captcha', function ($message, $attribute, $rule, $parameters) {
            return __('The captcha you entered does not match the image.');
        });

        Paginator::useBootstrap();
    }
}
