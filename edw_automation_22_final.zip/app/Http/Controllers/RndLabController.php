<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// Custom Class Import
use App\Helpers\RitHelper;

class RndLabController extends Controller
{
    public function testHelperClass(Request $request)
    {             
        echo RitHelper::titleCase("hello world");

        return view('not_needed_view');
    }

    public function testDbRecord(Request $request)
    {             
        $departments = RitHelper::getActiveDepartments();

        foreach ($departments as $department) 
        {
            echo $department->id . ' - ' . $department->name.'<br/>';
        }

        return view('not_needed_view');
    }

    public function dashboard(Request $request)
    {             
        
        return view('admin.dashboard');
    }
}
