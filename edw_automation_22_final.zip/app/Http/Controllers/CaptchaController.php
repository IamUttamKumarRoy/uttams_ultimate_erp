<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Session;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Str;


class CaptchaController extends Controller
{
    public function generate()
    {
        // Generate a random string
        $captchaText = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 6);
        //$captchaText = substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"), 0, 6);
        Session::put('captcha', $captchaText);

        // Create an image
        $image = imagecreate(120, 40);
        $background = imagecolorallocate($image, 255, 255, 255);
        $textColor = imagecolorallocate($image, 0, 0, 0);
        imagestring($image, 5, 10, 10, $captchaText, $textColor);

        // Output the image as PNG
        header("Content-type: image/png");
        imagepng($image);
        imagedestroy($image);
    }  

    public function generateCaptchaV2()
    {
        $captchaText = substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"), 0, 6);
        Session::put('captcha', $captchaText);

        // Create an image
        $width = 150;
        $height = 50;
        $image = imagecreate($width, $height);
        
        // Colors
        $background = imagecolorallocate($image, 255, 255, 255);
        $textColor = imagecolorallocate($image, 0, 0, 0);
        $borderColor = imagecolorallocate($image, 0, 0, 0); // Black border
        
        // Draw border
        imagerectangle($image, 0, 0, $width - 1, $height - 1, $borderColor);

        // Set font size and position
        $fontSize = 10; // Font size ranges from 1 to 5 in imagestring()
        $xPosition = 20;
        $yPosition = 15;

        imagestring($image, $fontSize, $xPosition, $yPosition, $captchaText, $textColor);

        // Output the image as PNG
        header("Content-type: image/png");
        imagepng($image);
        imagedestroy($image);
    }  
}
