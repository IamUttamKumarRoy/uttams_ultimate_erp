<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

use Maatwebsite\Excel\Facades\Excel;

// Model import 
use App\Models\User;



class LabController extends Controller
{
    public function captchaShow(Request $request)
    {        
        // Retrieve a session value
        $captcha_val = $request->session()->get('captcha');
        //return view('labs.captcha_show');
        return view('labs.captcha_form',compact('captcha_val'));
    }

    public function captchaValidate(Request $request)
    {

        $validated = $request->validate([
            'captcha' => 'required|captcha',
        ]);

        dd($validated);

        /*$rules = [
            // Other validation rules for your form fields
            'captcha' => 'required|captcha',
        ];


        $messages = [
            'captcha.required' => 'Please enter the captcha text.',
        ];

        $credentials = $request->validate([
            'user_id' => 'required',
            'password' => 'required',
            'captcha'  => 'required|captcha',
        ]);*/

        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) 
        {
            
            //return back()->withErrors($validator)->withInput();
            return back()->withErrors(['captcha' => 'The captcha you entered does not match the image']);
        }

        // Process your form data here
        dd('Form submitted successfully!');
    }

    public function loginForm(Request $request)
    {        
        if (auth()->check()) {
            return redirect('/dashboard');
        }
        return view('labs.login');
    }

    public function login(Request $request)
    {         
        $credentials = $request->validate([
            'user_id' => 'required',
            'password' => 'required',
            'captcha'  => 'required|captcha',
        ]);
        echo "This should be not printed";
        /*if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
 
            return redirect()->intended('dashboard');
        }*/

        // get user data for the given user_id
        $user = User::where('user_id', $request->user_id)->first();

        // check record exist or not with the given user_id 
        if ($user)
        {
            
            unset($credentials['captcha']);
            //echo "User_Id exist <br/>";
            // Check the password is hashed with Bcrypt or not             
            if (Hash::isHashed($user->password)) 
            {
                //echo "This is already a Bcrypt hash.<br/>";


                //if (Auth::attempt(['user_id' => $request->user_id, 'password' => $request->password],true)) 
                if (Auth::attempt($credentials))
                {
                    //echo "Login successful.<br/>";
                    //Auth::login($user);
                    //Auth::guard('web')->login($user);    
                    $request->session()->regenerate(); // Ensure session is stored

                    //dd(Auth::check(), Auth::user(), Session::all());
                    return redirect()->route('dashboard')->with('success', 'Login successful');
                }
                //echo "Login unsuccessful.<br/>";
                //dd($user);
                return back()->withErrors(['user_id' => 'Invalid credentials']);
            } 
            else 
            {
                echo "This is not a Bcrypt hash.<br/>";
                
                //dd($user);
                // The password is stored using md5 hashing
                if ($user && md5($request->password) === $user->password) 
                {
                    //echo "Md5 Hashing matched<br/>";
                    
                    // Rehash the password using bcrypt   
                    $updated_password_bcrypt = Hash::make($request->password); 
                    $temp_password = $user->password;

                    // Update with the bcrypt hashing                                
                    $user->password      = $updated_password_bcrypt;
                    $user->temp_password = $temp_password;
                    $user->save();

                    //echo "<br/>";
                    //echo $updated_password_bcrypt;
                    //echo "<br/>";
                    //echo $temp_password;
                    //echo "<br/>";
                    //if (Auth::attempt(['user_id' => $request->user_id, 'password' => $request->password],true)) 
                    if (Auth::attempt($credentials)) 
                    {

                        //Auth::login($user);
                        //Auth::guard('web')->login($user);
                        $request->session()->regenerate(); // Ensure session is stored

                        //echo "login with md5 successful";
                        //dd(Auth::check(), Auth::user(), Session::all());
                        return redirect()->route('dashboard')->with('success', 'Login successful');
                    }
                    echo "login unsuccessful";
                    dd($user);
                    return back()->withErrors(['user_id' => 'Invalid credentials']); 
                } 
                //echo "password not matched";
                //dd($user);  
                return back()->withErrors(['user_id' => 'Invalid credentials']);                             
            }
        }
        else
        {
            //echo "User_Id not exist<br/>";
            return back()->withErrors(['user_id' => 'User_Id not exist']);
        }         
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        
        return redirect('/');
    }

    public function importForm()
    {
        return view('labs.import_form'); // Create a Blade view for the upload form
    }

    public function import(Request $request)
    {

        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv',
        ]);

        $array = Excel::toArray([], $request->file('file'));
        dd($array);

        // Or:
        $collection = Excel::toCollection([], $request->file('file'));
        dd($collection);

        /*
        $request->validate([
            'file' => 'required|mimes:xlsx,xls',
        ]);

        Excel::import(new UsersImport, $request->file('file'));

        return redirect()->route('import.form')->with('success', 'Excel file imported successfully!');
        */
    }

}
