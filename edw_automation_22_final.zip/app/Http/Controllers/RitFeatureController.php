<?php
// app/Http/Controllers/RitFeatureController.php
namespace App\Http\Controllers;

use App\Models\RitFeature;
use Illuminate\Http\Request;

class RitFeatureController extends Controller
{
    // Display a listing of the RIT features
    public function index()
    {
        $ritFeatures = RitFeature::latest()->paginate(10);
        return view('rit_features.index', compact('ritFeatures'));
    }

    // Show the form for creating a new RIT feature
    public function create()
    {
        return view('rit_features.create');
    }

    // Store a newly created RIT feature in the database
    public function store(Request $request)
    {
        $request->validate([
            'rit_id' => 'required|unique:rit_features',
            'rit_name' => 'required|string|max:200',
            'rit_freq' => 'required|string|max:100',
            'data_frequency_id' => 'nullable|integer',
            'rit_version' => 'required|integer',
            'no_of_col' => 'required|integer',
            'no_of_row' => 'required|integer',
            'cut_off_days' => 'required|integer',
            'dept' => 'required|string|max:100',
            'department_id' => 'nullable|integer',
            'status' => 'required|max:100',
            'status_id' => 'required|integer',
            'validate' => 'required|integer',
        ]);

        RitFeature::create($request->all());
        return redirect()->route('rit-features.index')->with('success', 'RIT Feature created successfully.');
    }

    // Display the specified RIT feature
    public function show(RitFeature $ritFeature)
    {
        return view('rit_features.show', compact('ritFeature'));
    }

    // Show the form for editing the specified RIT feature
    public function edit(RitFeature $ritFeature)
    {
        return view('rit_features.edit', compact('ritFeature'));
    }

    // Update the specified RIT feature in the database
    public function update(Request $request, RitFeature $ritFeature)
    {
        $request->validate([
            'rit_id' => 'required|unique:rit_features,rit_id,' . $ritFeature->id,
            'rit_name' => 'required|string|max:200',
            'rit_freq' => 'required|string|max:100',
            'data_frequency_id' => 'nullable|integer',
            'rit_version' => 'required|integer',
            'no_of_col' => 'required|integer',
            'no_of_row' => 'required|integer',
            'cut_off_days' => 'required|integer',
            'dept' => 'required|string|max:100',
            'department_id' => 'nullable|integer',
            'status' => 'required|string|max:100',
            'status_id' => 'required|integer',
            'validate' => 'required|integer',
        ]);

        $ritFeature->update($request->all());
        return redirect()->route('rit-features.index')->with('success', 'RIT Feature updated successfully.');
    }

    // Remove the specified RIT feature from the database
    public function destroy(RitFeature $ritFeature)
    {
        $ritFeature->delete();
        return redirect()->route('rit-features.index')->with('success', 'RIT Feature deleted successfully.');
    }
}