<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class FileUploadController2 extends Controller
{
    /**
     * Show the file upload form.
     */
    public function create()
    {
        // Define the required filename to show it to the user in the view
        $requiredFilename = 'terms_and_conditions_signed.pdf';
        return view('upload-form', compact('requiredFilename'));
    }


    public function upload(Request $request)
    {
        dd($request);

        // Validate request
        $submitted_file = $request->validate([
            'file' => 'required|file|mimes:pdf,jpg,png|max:5120', // 5MB max
            'custom_name' => 'required|string|max:100',
        ]);

        

        $file = $request->file('file');
        $customName = $request->input('custom_name');
        $extension = $file->extension();
        
        // Generate final filename (slugified)
        $finalFilename = Str::slug($customName) . '.' . $extension;

        // Step 1: Temporarily store the file
        $tempPath = $file->storeAs('temp', $finalFilename);

        // Step 2: Validate filename (custom rules)
        if (!$this->isFilenameValid($finalFilename)) {
            Storage::delete($tempPath); // Delete if invalid
            return back()->with('error', 'Invalid filename format!');
        }

        // Step 3: Move to permanent storage if validation passes
        $permanentPath = 'uploads/' . $finalFilename;
        Storage::move($tempPath, $permanentPath);

        return back()->with('success', 'File uploaded successfully!');
    }

    /**
     * Custom filename validation rules.
     */
    protected function isFilenameValid(string $filename): bool
    {
        // Rule 1: No special chars except (-, _, .)
        if (preg_match('/[^a-zA-Z0-9\-_.]/', $filename)) {
            return false;
        }

        // Rule 2: No reserved names (e.g., 'admin', 'config')
        $reservedNames = ['admin', 'config', 'system'];
        $nameWithoutExt = pathinfo($filename, PATHINFO_FILENAME);
        
        if (in_array(strtolower($nameWithoutExt), $reservedNames)) {
            return false;
        }

        // Rule 3: Max length check
        if (strlen($filename) > 100) {
            return false;
        }

        return true;
    }
}