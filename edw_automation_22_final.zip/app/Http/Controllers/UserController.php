<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session; // Import the Session class

use App\Helpers\RitHelper;
use App\Models\User; 






class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        /*$users = User::latest()->paginate(10);
        return view('users.index', compact('users'));*/
        $users = User::latest()->paginate(10);
        //$users = User::paginate(10); // Paginate the User model, 10 items per page
        return view('users.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $active_roles    = RitHelper::getActiveRoles();
        $active_bank_fis = RitHelper::getActiveBankFi();

        return view('users.create',compact('active_bank_fis','active_roles'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        /*$validated_data = $request->validate([
            'role_id'          => 'required',
            'fi_id'            => 'required',   
            'bank_branch_id'   => 'required',                
            //'user_id'          => 'required',
            'user_id'          => 'required|string|unique:users,user_id',
            'user_name'        => 'required', 
            'designation'      => 'required', 
            'dept_sec_desk'    => 'required', 
            'email'            => 'required', 
            'cell_no  '        => 'required', 
            'password  '       => 'required', 
            'confirm_password' => 'required', 
        ]);
        */
        // Validate the request
        $validatedData = $request->validate([
            'role_id'          => 'required',
            'fi_id'            => 'required',
            'bank_branch_id'   => 'required',
            'user_id'          => 'required|string|unique:users,user_id',
            'user_name'        => 'required',
            'designation'      => 'required',
            'dept_sec_desk'    => 'required',
            //'email'            => 'required|email|unique:users,email',
            'email'            => 'required|email',
            'cell_no'          => 'required',
            'password'         => 'required|min:8',
            'confirm_password' => 'required|same:password',
        ]);

        // Check if user with given username already exists
        if (User::where('user_id', $validatedData['user_id'])->exists()) {
            return redirect()->back()->with('error', 'Username already exists.')->withInput();
        } 
        
        // Needed variables
        //Getting User’s IP Address
        $ip_address   = $request->ip();  
        //Retrieving the User-Agent
        $user_agent   = $request->header('User-Agent');  

        $validatedData['status_id']  = 1;
        $validatedData['online']     = 1;
        $validatedData['block']      = 0;
        $validatedData['ip_address'] = $ip_address;
        $validatedData['user_agent'] = $user_agent;

        // Hash the password
        $validatedData['password'] = Hash::make($validatedData['password']);

        // Remove confirm_password from the array since it won't be stored
        unset($validatedData['confirm_password']);

        // Create the user
        $user = User::create($validatedData);

        // Redirect back to the previous page (the form) with a success flash message
        return redirect()->back()->with('success', 'User created successfully!');


    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function blockedUserlist()
    {
        $users = User::where('block', '=', 1)->paginate(10);
       
        return view('users.blocked_user', compact('users'));
    }

    public function inactiveUserlist()
    {
        $users = User::where('online', '=', 0)->paginate(10);
       
        return view('users.inactive_user', compact('users'));
    }

    public function adminUserList()
    {
        $users = User::where('role_id', '=', 104)->paginate(10);
       
        return view('users.admin_user', compact('users'));
    }

    public function activeUserList()
    {
        $users = User::where('online', '=', 1)->paginate(10);
       
        return view('users.active_user', compact('users'));
    }

    /**
     * Show the user's profile page.
     *
     * @return \Illuminate\View\View
     */
    public function profile()
    {
        $user = Auth::user(); // Get the currently authenticated user

        $logged_user_name      = $user->user_name;
        $logged_fi_id          = $user->fi_id;
        $bank_branch_id        = $user->bank_branch_id;

        $bank_fi   = RitHelper::getBankFi($logged_fi_id);
        $bank_name   = $bank_fi->fi_nm;
        //print_r($bank_name);

        $bank_branch = RitHelper::getBankBranch($bank_branch_id);
        $bank_branch_name   = $bank_branch->branch_name;

        $auth_user_str = "{$logged_user_name}";
        $auth_user_str = "{$logged_user_name}, {$bank_branch_name}, {$bank_name}";

        return view('users.profile', compact('user','bank_name','bank_branch_name'));
    }

    // Show login form
    public function addMdForm()
    {        
        $active_bank_fis = RitHelper::getActiveBankFi();

        return view('users.add_md_form',compact('active_bank_fis'));
    }

    public function addMdUser(Request $request)
    {

    }
}

