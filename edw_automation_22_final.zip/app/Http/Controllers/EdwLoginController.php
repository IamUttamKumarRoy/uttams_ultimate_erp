<?php

namespace App\Http\Controllers;

// Library import
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\Validator;

use App\Helpers\RitHelper;
use App\Models\User; 


class EdwLoginController extends Controller
{
    // Show Registration form
    public function registerForm(Request $request)
    {        
        $active_bank_fis = RitHelper::getActiveBankFi();
        $test_var = '';
        return view('edw_auth.register-user',compact(
                'test_var','active_bank_fis'
            )
        ); 
    }    
    public function registration(Request $request)
    {         
        $credentials = $request->validate([
            'user_id' => 'required',
            'password' => 'required',
            'captcha'  => 'required|captcha',
        ]);


    }
    
    public function sbsCodeUserLimit(Request $request)
    {        
        //$exists = DB::table('users')->where('sbs_code', $request->sbs_code)->exists();
        $fi_branch_id = $request->sbs_code;
        $userCount = User::where('status_id', 1)             
             ->where('bank_branch_id', $fi_branch_id)              
             ->count(); 
        if( !empty($userCount) ) {
            return response()->json(['exists' => $exists]);
        } else {
            return response()->json();
        }
        
    }
    
    // Show login form
    public function loginForm(Request $request)
    {        
        if (auth()->check()) {
            return redirect('/dashboard');
        }

        // Store a session value
        $request->session()->put('test_key', 'test_value');

        // Retrieve a session value
        $value = $request->session()->get('test_key');

        //check if the value was stored.
        //dd($value);

        return view('edw_auth.login');
    }

    public function login(Request $request)
    {         
        $credentials = $request->validate([
            'user_id' => 'required',
            'password' => 'required',
            'captcha'  => 'required|captcha',
        ]);
        echo "This should be not printed";
        /*if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
 
            return redirect()->intended('dashboard');
        }*/

        // get user data for the given user_id
        $user = User::where('user_id', $request->user_id)->first();

        // check record exist or not with the given user_id 
        if ($user)
        {
            
            unset($credentials['captcha']);
            //echo "User_Id exist <br/>";
            // Check the password is hashed with Bcrypt or not             
            if (Hash::isHashed($user->password)) 
            {
                //echo "This is already a Bcrypt hash.<br/>";


                //if (Auth::attempt(['user_id' => $request->user_id, 'password' => $request->password],true)) 
                if (Auth::attempt($credentials))
                {
                    //echo "Login successful.<br/>";
                    //Auth::login($user);
                    //Auth::guard('web')->login($user);    
                    $request->session()->regenerate(); // Ensure session is stored

                    //dd(Auth::check(), Auth::user(), Session::all());
                    return redirect()->route('dashboard')->with('success', 'Login successful');
                }
                //echo "Login unsuccessful.<br/>";
                //dd($user);
                return back()->withErrors(['user_id' => 'Invalid credentials']);
            } 
            else 
            {
                echo "This is not a Bcrypt hash.<br/>";
                
                //dd($user);
                // The password is stored using md5 hashing
                if ($user && md5($request->password) === $user->password) 
                {
                    //echo "Md5 Hashing matched<br/>";
                    
                    // Rehash the password using bcrypt   
                    $updated_password_bcrypt = Hash::make($request->password); 
                    $temp_password = $user->password;

                    // Update with the bcrypt hashing                                
                    $user->password      = $updated_password_bcrypt;
                    $user->temp_password = $temp_password;
                    $user->save();

                    //echo "<br/>";
                    //echo $updated_password_bcrypt;
                    //echo "<br/>";
                    //echo $temp_password;
                    //echo "<br/>";
                    //if (Auth::attempt(['user_id' => $request->user_id, 'password' => $request->password],true)) 
                    if (Auth::attempt($credentials)) 
                    {

                        //Auth::login($user);
                        //Auth::guard('web')->login($user);
                        $request->session()->regenerate(); // Ensure session is stored

                        //echo "login with md5 successful";
                        //dd(Auth::check(), Auth::user(), Session::all());
                        return redirect()->route('dashboard')->with('success', 'Login successful');
                    }
                    echo "login unsuccessful";
                    dd($user);
                    return back()->withErrors(['user_id' => 'Invalid credentials']); 
                } 
                //echo "password not matched";
                //dd($user);  
                return back()->withErrors(['user_id' => 'Invalid credentials']);                             
            }
        }
        else
        {
            //echo "User_Id not exist<br/>";
            return back()->withErrors(['user_id' => 'User_Id not exist']);
        }         
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        
        return redirect('/');
    }

    public function showChangePasswordForm()
    {
        return view('edw_auth.forget_password');
    }


    public function submitChangePasswordForm(Request $request)
    {
        // Validate the input
        $request->validate([
            'current_password' => ['required'], // Optional: Verify current password
            'new_password' => [
                'required',
                'string',
                'min:8', // Minimum length of 8 characters
                'confirmed', // Ensures new_password and new_password_confirmation match
                Password::min(8)->letters()->numbers()->symbols(), // Enforces complexity: letters, numbers, symbols
            ],
        ]);

        // Retrieve the authenticated user
        $user = Auth::user();

        // Verify the current password
        if (!Hash::check($request->current_password, $user->password)) {
            return back()->withErrors(['current_password' => 'The current password is incorrect.']);
        }

        // Update the user's password
        $user->update([
            'password' => Hash::make($request->new_password),
        ]);

        // Redirect with success feedback
        return redirect()
            ->route('dashboard')
            ->with('success', 'Your password has been changed successfully!');

        //  End     
        /*
        $request->validate([
            'current_password' => ['required', 'current_password'], // Laravel's built-in current_password validation rule
            'new_password' => ['required', 'min:8', 'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/'], // Consider adding minimum length and confirmed rule
            'new_password_confirmation' => ['same:new_password'], // It's good practice to explicitly validate the confirmation field
        ]);

        //'new_password' => ['required', 'min:8', 'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/', 'confirmed'],

        $user = Auth::user();

        $user->update(['password' => Hash::make($request->new_password)]);

        return redirect()->route('dashboard.adminlte')->with('success', 'Your password has been changed successfully!');

        $request->validate([
            'new_password' => ['required'],
            'new_confirm_password' => ['same:new_password'],
        ]);

        $user = Auth::user(); 

        $user_id  = $user->user_id;


        $user = User::where('user_id', $user_id)
                  ->update(['password' => Hash::make($request->new_password)]);

        return redirect()->route('dashboard.adminlte')->with('success', 'Your password has been changed successfully!');*/

    }
}
