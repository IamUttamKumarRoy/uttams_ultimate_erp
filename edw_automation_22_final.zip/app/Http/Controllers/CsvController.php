<?php
 
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BankBranch;
use App\Models\BankFi;
use Illuminate\Support\Facades\Validator;

class CsvController extends Controller
{
    // Show the CSV upload form
    public function showUploadForm()
    {
        return view('upload-csv');
    }

    // Process the uploaded CSV file
    public function processCsv(Request $request)
    {
        // Validate the uploaded file
        $request->validate([
            'csv_file' => 'required|file|mimes:csv,txt',
        ]);

        // Get the uploaded file
        $file = $request->file('csv_file');

        // Open the file for reading
        $handle = fopen($file->getPathname(), 'r');

        // Skip the header row
        fgetcsv($handle);

        // Process each row of the CSV file
        //while (($data = fgetcsv($handle)) 
        while (($data = fgetcsv($handle, 1000, ',')) !== FALSE)
        {
            // Map CSV columns to database fields
            $row = [
                'fi_branch_id' => $data[0],
                'fi_id' => $data[1],
                'branch_name' => $data[2],
                'division' => $data[3],
                'district' => $data[4],
                'thana' => $data[5],
            ];

            // Validate the row data
            $validator = Validator::make($row, [
                'fi_branch_id' => 'required|integer',
                'fi_id' => 'required|integer',
                'branch_name' => 'nullable|string|max:100',
                'division' => 'nullable|string|max:50',
                'district' => 'nullable|string|max:50',
                'thana' => 'nullable|string|max:50',
            ]);

            // If validation fails, skip the row
            if ($validator->fails()) {
                continue;
            }

            // Insert the row into the database
            BankBranch::create($row);
        }

        // Close the file
        fclose($handle);

        return redirect()->back()->with('success', 'CSV data imported successfully.');
    }

    // Show the CSV upload form
    public function uploadBankFiCsv()
    {
        return view('upload_bank_fi_csv');
    }

    // Process the uploaded CSV file
    public function processBankFiCsv(Request $request)
    {
        // Validate the uploaded file
        $request->validate([
            'csv_file' => 'required|file|mimes:csv,txt',
        ]);

        // Get the uploaded file
        $file = $request->file('csv_file');

        // Open the file for reading
        $handle = fopen($file->getPathname(), 'r');

        // Skip the header row
        fgetcsv($handle);

        // Process each row of the CSV file
        //while (($data = fgetcsv($handle)) 
        while (($data = fgetcsv($handle, 1000, ',')) !== FALSE)
        {
            // Map CSV columns to database fields
            $row = [
                'FI_ID'       => $data[0],
                'FI_NM'       => $data[1],
                'FI_ALIAS'    => $data[2],
                'GEO_AREA_ID' => $data[3],
                'FI_CLASS_ID' => $data[4],
            ];

            $row = [
                'fi_id'            => $data[0],
                'fi_nm'            => $data[1],
                'fi_alias'         => $data[2],
                'geo_area_id'      => $data[3],
                'bank_fi_class_id' => $data[4],
            ];


            // Validate the row data
            $validator = Validator::make($row, [
                'fi_id'           => 'required|integer',
                'fi_nm'           => 'required',
                'fi_alias'        => 'nullable|string|max:100',
                'geo_area_id'     => 'nullable|integer',
                'bank_fi_class_id'=> 'nullable|integer' 
            ]);

            // If validation fails, skip the row
            if ($validator->fails()) {
                continue;
            }



            // Insert the row into the database
            BankFi::create($row);
        }
       

        // Close the file
        fclose($handle);

         //dd($row);
         //exit();

        return redirect()->back()->with('success', 'CSV data imported successfully.');
    }
}