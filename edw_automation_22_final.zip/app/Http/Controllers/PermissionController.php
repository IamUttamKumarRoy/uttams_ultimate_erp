<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;

use App\Models\Permission;


class PermissionController extends Controller
{
    public function index()
    {
        $permissions = Permission::latest()->paginate(10);
        return view('permissions.index', compact('permissions'));
    }

    public function create()
    {
        return view('permissions.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100|unique:permissions',
            'route_name' => 'nullable|string|max:100',
            'route_uri' => 'nullable|string|max:200',
            'route_action' => 'nullable|string|max:100',
            'action_method' => 'nullable|string|max:100',
            'http_method' => 'nullable|string|max:10',
            'status_id' => 'nullable|integer',
        ]);

        $data = $request->all();
        $data['ip_address'] = $request->ip();
        $data['user_agent'] = $request->userAgent();

        Permission::create($data);

        return redirect()->route('permissions.index')
            ->with('success', 'Permission created successfully.');
    }

    public function show(Permission $permission)
    {
        return view('permissions.show', compact('permission'));
    }

    public function edit(Permission $permission)
    {
        return view('permissions.edit', compact('permission'));
    }

    public function update(Request $request, Permission $permission)
    {
        $request->validate([
            'name' => 'required|string|max:100|unique:permissions,name,' . $permission->id,
            'route_name' => 'nullable|string|max:100',
            'route_uri' => 'nullable|string|max:200',
            'route_action' => 'nullable|string|max:100',
            'action_method' => 'nullable|string|max:100',
            'http_method' => 'nullable|string|max:10',
            'status_id' => 'nullable|integer',
        ]);

        $data = $request->all();
        $data['ip_address'] = $request->ip();
        $data['user_agent'] = $request->userAgent();

        $permission->update($data);

        return redirect()->route('permissions.index')
            ->with('success', 'Permission updated successfully');
    }

    public function destroy(Permission $permission)
    {
        $permission->delete();

        return redirect()->route('permissions.index')
            ->with('success', 'Permission deleted successfully');
    }

    public function storeRoutes()
    {
        // Get all registered routes
        $routes = Route::getRoutes();

        foreach ($routes as $route) {
            $name = $route->getName(); // Get route name
            $method = implode(',', $route->methods()); // Get HTTP methods
            $uri = $route->uri(); // Get URI path

            if ($name) { // Ensure the route has a name
                Permission::updateOrCreate(
                    ['name' => $name], // Unique route name
                    ['method' => $method, 'uri' => $uri] // Additional info
                );
            }
        }

        return response()->json(['message' => 'Routes inserted successfully']);
    }
    public function syncPermissions()
    {
        $routes = Route::getRoutes();
        $newPermissions = [];

        foreach ($routes as $route) 
        {

            if ($route->getAction('controller')) 
            {
                //dd($route);
                //break;
                $uri     = $route->uri();
                $name    = $route->getName();
                $methods = $route->methods();
                $action  = $route->getAction('controller');

                // You might want to customize how you generate the permission 'slug'
                $slug = str_replace(['.', '/'], '-', $name ?: $uri);

                /*$newPermissions[] = [
                    'name' => $name ?: $uri, // Use name if available, otherwise URI
                    'slug' => $slug,
                    'http_method' => implode('|', $methods),
                    'controller_action' => $action,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];*/
                $newPermissions[] = [
                    'name'          => $name ?: $uri, // Use name if available, otherwise URI
                    'route_name'    => $name,
                    'route_uri'     => $uri,
                    'route_action'  => $action,                    
                    'action_method' => $action,
                    'http_method'   => implode('|', $methods),
                    'status_id'     => 1,
                    'ip_address'    => request()->ip(),
                    'user_agent'    => request()->userAgent()
                ];
            }
        }
        dd($newPermissions);
        // Get existing permissions to avoid duplicates
        $existingSlugs = DB::table('permissions')->pluck('slug')->toArray();

        $permissionsToInsert = collect($newPermissions)
            ->reject(fn ($permission) => in_array($permission['slug'], $existingSlugs))
            ->toArray();

        if (!empty($permissionsToInsert)) {
            DB::table('permissions')->insert($permissionsToInsert);
            return response()->json(['message' => 'Permissions synced successfully. ' . count($permissionsToInsert) . ' new permissions added.']);
        }

        return response()->json(['message' => 'No new permissions to sync.']);
    }

    public function saveRoutes()
    {
        //$routes = \Illuminate\Support\Facades\Route::getRoutes();
        $routes = Route::getRoutes();
        $inc = 0;
        foreach ($routes as $route) 
        {
            if ($route->getName()) 
            {

                Permission::firstOrCreate([
                    'name'          => $route->getName()."".$inc,
                    'route_name'    => $route->getName(),
                    'route_uri'     => $route->uri(),
                    'route_action'  => $route->getActionName(),
                    'action_method' => $route->getActionMethod(),
                    'http_method'   => implode('|', $route->methods()),
                    'status_id'     => 1,
                    'ip_address'    => request()->ip(),
                    'user_agent'    => request()->userAgent()
                ]);
                $inc++;
            }
        }
        
        //$this->info('Permissions generated successfully!');
    }
    public function addRoutes()
    {
        //$routes = \Illuminate\Support\Facades\Route::getRoutes();
        $routes = Route::getRoutes();
        $inc = 0;
        foreach ($routes as $route) 
        {
            //if ($route->getName()) 
            if ($route->getAction('controller')) 
            {
                $action = $route->getActionName();
                $controller_name = '';
                if (isset($action['controller'])) {
                    $controller_name= is_string($action['controller']) 
                        ? explode('@', $action['controller'])[0]
                        : get_class($action['controller']);
                }

                Permission::firstOrCreate([
                    'name'          => $route->getName()."".$inc,
                    'route_name'    => $route->getName(),
                    'route_uri'     => $route->uri(),
                    'route_action'  => $route->getActionName(),
                    'action_controller'  => $controller_name,
                    'action_method' => $route->getActionMethod(),
                    'http_method'   => implode('|', $route->methods()),
                    'status_id'     => 1,
                    'ip_address'    => request()->ip(),
                    'user_agent'    => request()->userAgent()
                ]);
                $inc++;
            }
        }
        
        //$this->info('Permissions generated successfully!');
    }
}