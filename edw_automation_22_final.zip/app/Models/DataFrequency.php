<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DataFrequency extends Model
{
    /** @use HasFactory<\Database\Factories\DataFrequencyFactory> */
    use HasFactory; 

    protected $table      = 'data_frequencies'; // Specify the table name
    protected $primaryKey = 'id'; // Specify the primary key

    protected $fillable = [
        'short_name',
        'full_name',
        'description',
        'status_id' 
    ]; 
} 