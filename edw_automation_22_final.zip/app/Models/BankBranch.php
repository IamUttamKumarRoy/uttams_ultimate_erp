<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BankBranch extends Model
{
    /** @use HasFactory<\Database\Factories\BankBranchFactory> */
    use HasFactory;

    protected $fillable = [
        'fi_branch_id', 
        'fi_id', 
        'branch_name', 
        'division', 
        'district',
        'thana',
        'status_id'
    ];
}
 