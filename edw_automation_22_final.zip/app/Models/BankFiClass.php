<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BankFiClass extends Model
{
    /** @use HasFactory<\Database\Factories\BankFiClassFactory> */
    use HasFactory;
	
	protected $table      = 'bank_fi_classes'; // Specify the table name
    protected $primaryKey = 'id'; // Specify the primary key

    protected $fillable = [
        'fi_class_id',
        'fi_inst_type',
        'fi_category',
        'fi_cluster' 
    ]; 
}
