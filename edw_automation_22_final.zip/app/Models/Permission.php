<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Permission extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'route_name', 
        'route_uri', 
        'route_action', 
        'action_controller', 
        'action_method', 
        'http_method', 
        'status_id', 
        'ip_address', 
        'user_agent' 
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
    /*
    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class);
    }
    */
    public function roles()
    {
        return $this->belongsToMany(Role::class);
    }
}
 