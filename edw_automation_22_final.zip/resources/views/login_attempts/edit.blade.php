@extends('layouts.app')

@section('content')
    <h1>Edit Login Attempt</h1>
    <form action="{{ route('login_attempts.update', $loginAttempt->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="user_id">User ID</label>
            <input type="text" name="user_id" class="form-control" value="{{ $loginAttempt->user_id }}" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" class="form-control" value="{{ $loginAttempt->password }}" required>
        </div>
        <div class="form-group">
            <label for="ip_address">IP Address</label>
            <input type="text" name="ip_address" class="form-control" value="{{ $loginAttempt->ip_address }}">
        </div>
        <div class="form-group">
            <label for="user_agent">User Agent</label>
            <input type="text" name="user_agent" class="form-control" value="{{ $loginAttempt->user_agent }}">
        </div>
        <div class="form-group">
            <label for="success">Success</label>
            <select name="success" class="form-control" required>
                <option value="1" {{ $loginAttempt->success ? 'selected' : '' }}>Yes</option>
                <option value="0" {{ !$loginAttempt->success ? 'selected' : '' }}>No</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
@endsection