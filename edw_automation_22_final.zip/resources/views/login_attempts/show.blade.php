@extends('layouts.app')

@section('content')
    <h1>Login Attempt Details</h1>
    <p><strong>User ID:</strong> {{ $loginAttempt->user_id }}</p>
    <p><strong>IP Address:</strong> {{ $loginAttempt->ip_address }}</p>
    <p><strong>User Agent:</strong> {{ $loginAttempt->user_agent }}</p>
    <p><strong>Success:</strong> {{ $loginAttempt->success ? 'Yes' : 'No' }}</p>
    <p><strong>Attempt Time:</strong> {{ $loginAttempt->attempt_time }}</p>
    <a href="{{ route('login_attempts.index') }}" class="btn btn-secondary">Back</a>
@endsection