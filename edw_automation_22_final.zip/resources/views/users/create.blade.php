@extends('layouts.adminlte_3') 

@section('content')
<div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-8">        
        <form class="form-horizontal" action="{{ route('users.store') }}" method="POST">
            @csrf {{-- Include the CSRF token --}}

            @if (session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif

            @if (session('status'))
                <div class="alert alert-success">
                    {{ session('status') }}
                </div>
            @endif
            @if ($errors->any())
                <div class="alert alert-danger">
                    <h5>Whoops! Something went wrong.</h5>
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Create User</h3>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label for="roleId" class="col-sm-3 col-form-label">User Role</label>
                        <div class="col-sm-9">
                            <select name="role_id" id="roleId" class="form-control">
                                <option value="" disabled selected>User Role:</option> 
                                @foreach ($active_roles as $role)
                                    <option value="{{ $role->role_id }}">{{ $role->show_name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>    
                    <div class="form-group row">
                        <label for="fiId" class="col-sm-3 col-form-label">Bank/FI Name</label>
                        <div class="col-sm-9">
                            <select name="fi_id" id="fiId" class="form-control select2">
                                <option value="">Select Bank Name:</option> 
                                @foreach ($active_bank_fis as $bank_fi)
                                    <option value="{{ $bank_fi->fi_id }}">{{ $bank_fi->fi_nm }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>  
                    <div class="form-group row">
                        <label for="bankBranchId" class="col-sm-3 col-form-label">Branch Name</label>
                        <div class="col-sm-9">                            
                            <select class="form-control" name="bank_branch_id" id="bankBranchId">
                                <option value="">Select Branch</option>
                            </select>
                        </div>
                    </div>  
                    <div class="form-group row">
                        <label for="userId" class="col-sm-3 col-form-label">User ID</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="user_id" id="userId" >
                        </div>
                    </div>                                                      
                    <div class="form-group row">
                        <label for="userName" class="col-sm-3 col-form-label">User Name</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="user_name" id="userName" placeholder="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="designation" class="col-sm-3 col-form-label">Designation</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="designation" id="designation" placeholder="">
                        </div>
                    </div>   
                    <div class="form-group row">
                        <label for="dept_sec_desk" class="col-sm-3 col-form-label">Department/Desk</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="dept_sec_desk" id="dept_sec_desk" placeholder="">
                        </div>
                    </div>                         
                                    
                    <div class="form-group row">
                        <label for="Email" class="col-sm-3 col-form-label">Email</label>
                        <div class="col-sm-9">
                            <input type="email" class="form-control" name="email" id="Email" placeholder="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="cell_no" class="col-sm-3 col-form-label">Cell Phone</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="cell_no" id="cell_no" placeholder="">
                        </div>
                    </div>                                                                             
                    <div class="form-group row">
                        <label for="password" class="col-sm-3 col-form-label">Password</label>
                        <div class="col-sm-9">
                            <input type="password" class="form-control" name ="password" id="password" placeholder="Password">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="confirmPassword" class="col-sm-3 col-form-label">Re-Type Password</label>
                        <div class="col-sm-9">
                            <input type="password" class="form-control" name="confirm_password" id="confirmPassword" placeholder="Password">
                        </div>
                    </div>                                          
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="submit" class="btn btn-default float-right">Cancel</button>
                </div>
                <!-- /.card-footer -->
            </div>
        </form>
      </div>
      <!--/.col  -->
    </div>
    <!-- /.row -->
</div>

<script>

$( function() {

    $('#fiId').change(function() {

        var bankId = $(this).val();

        if (bankId) {
            $.ajax({
                url: '{{ route('ajax.get-branches-by-bank') }}', 
                type: 'POST',
                data: { fi_id: bankId },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') // Ensure CSRF protection
                },
                success: function(response) {
                    $('#bankBranchId').empty().append('<option value="">Select Branch</option>');

                    $.each(response, function(fi_branch_id, branch_name) {
                        $('#bankBranchId').append('<option value="' + fi_branch_id + '">' + branch_name + '</option>');
                    });
                },
                error: function() {
                    alert('Error fetching branches.');
                }
            });
        } else {
            $('#bankBranchId').empty().append('<option value="">Select Branch</option>');
        }
    });

     $('#bankBranchId').change(function() {
        var bankId   = $('#fiId').val();
        var branchId = $(this).val();

        if (bankId && branchId) {
            $.ajax({
                url: '{{ route('ajax.get-user-id') }}',
                type: 'POST',
                data: { fi_id: bankId, bank_branch_id: branchId },
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                success: function(response) {
                    $('#userId').val(response.user_id); // Set User ID in input field
                },
                error: function() {
                    alert('Error generating user ID.');
                }
            });
        }
    });
});

</script>
@endsection