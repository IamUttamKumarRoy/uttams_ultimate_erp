@extends('layouts.adminlte_3') 

@section('content')
     
<div class="container-fluid">
    <div class="row">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Users</h3>                
                <div class="text-right"> <a href="{{ route('users.create') }}" class="btn btn-primary mb-3">Create New User</a> </div>                            
            </div>
            
            <div class="card-body">
            @if(session('success'))
                    <div class="alert alert-success">{{ session('success') }}</div>
                @endif

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Bank Code</th>
                            <th>Bank Name</th>
                            <th>Branch Name</th>
                            <th>User Name</th>
                            <th>User ID</th>
                            <th>Designation</th>
                            <th>Desk</th>
                            <th>Email</th>
                            <th>Cell No.</th>
                            <th>Phone No</th>
                            <th>Role</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>            
                        <?php $inc = 1; ?>
                        @foreach($users as $user)
                            <tr>
                                <td>{{ $inc++ }}</td>
                                <td>{{ $user->fi_id }}</td>
                                <td>{{ $user->fi_id }}</td>
                                <td>{{ $user->bank_branch_id }}</td>
                                <td>{{ $user->bank_branch_id }}</td>
                                <td>{{ $user->user_name }}</td>
                                <td>{{ $user->user_id }}</td>
                                <td>{{ $user->designation }}</td>
                                <td>{{ $user->dept_sec_desk }}</td>
                                <td>{{ $user->cell_no }}</td>
                                <td>{{ $user->phone_no }}</td>
                                <td>{{ $user->role_id }}</td>
                                <td>
                                    <a href="{{ route('users.show', $user->id) }}" class="btn btn-info btn-sm">View</a>
                                    <a href="{{ route('users.edit', $user->id) }}" class="btn btn-primary btn-sm">Edit</a>
                                    <form action="{{ route('users.destroy', $user->id) }}" method="POST" class="d-inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                                    </form>
                                </td>
                            </tr>                                
                        @endforeach
                    </tbody>
                </table>

                {{ $users->links() }} {{-- This renders the pagination links --}}
            </div>
        </div>
    </div>
</div>
 @endsection