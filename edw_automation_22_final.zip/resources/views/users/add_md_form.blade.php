@extends('layouts.adminlte_3') 

@section('content')
<div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-6">
        <form class="form-horizontal">
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Create Bank MD User</h3>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label for="userName" class="col-sm-2 col-form-label">User Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="user_name" id="userName" placeholder="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="designation" class="col-sm-2 col-form-label">Designation</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="designation" id="designation" placeholder="">
                        </div>
                    </div>                    
                    <div class="form-group row">
                        <label for="fiId" class="col-sm-2 col-form-label">FI Name</label>
                        <div class="col-sm-10">
                            <select name="fi_id" id="fiId" class="form-control">
                                <option value="" disabled selected>Bank Name:</option> 
                                @foreach ($active_bank_fis as $bank_fi)
                                    <option value="{{ $bank_fi->fi_id }}">{{ $bank_fi->fi_nm }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="bankBranchId" class="col-sm-2 col-form-label">Branch Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="bank_branch_id" id="bankBranchId" placeholder="">
                        </div>
                    </div>                                                                              
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-10">
                            <input type="password" class="form-control" id="inputPassword3" placeholder="Password">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-10">
                            <input type="password" class="form-control" id="inputPassword3" placeholder="Password">
                        </div>
                    </div>                    
                    <div class="form-group row">
                        <label for="Email" class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" name="email" id="Email" placeholder="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="phoneNo" class="col-sm-2 col-form-label">Cell Phone</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="phone_no" id="phone_no" placeholder="">
                        </div>
                    </div>                       
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="submit" class="btn btn-default float-right">Cancel</button>
                </div>
                <!-- /.card-footer -->
            </div>
        </form>
      </div>
      <!--/.col  -->
    </div>
    <!-- /.row -->
</div>
@endsection