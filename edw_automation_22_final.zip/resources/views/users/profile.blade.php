@extends('layouts.adminlte_3') 

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ __('Your Profile') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <p><strong>{{ __('Name:') }}</strong> {{ $user->user_name }}</p>
                    <p><strong>{{ __('Designnation:') }}</strong> {{ $user->designation }}</p>
                    <p><strong>{{ __('Desk:') }}</strong> {{ $user->dept_sec_desk }}</p>
                    <p><strong>{{ __('Cell No:') }}</strong> {{ $user->cell_no }}</p>
                    <p><strong>{{ __('Phone no:') }}</strong> {{ $user->phone_no }}</p>
                    <p><strong>{{ __('Email:') }}</strong> {{ $user->email }}</p>

                    {{-- Add other user information you want to display --}}

                    <a href="{{ route('dashboard') }}" class="btn btn-primary">{{ __('Back to Home') }}</a>
                    {{-- You might add an "Edit Profile" button here later --}}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection