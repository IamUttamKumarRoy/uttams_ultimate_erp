@extends('layouts.app')

@section('content')
    <h1>Edit Submission</h1>
    <form action="{{ route('rit_submissions.update', $ritSubmission->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="file_name">File Name</label>
            <input type="text" name="file_name" class="form-control" value="{{ $ritSubmission->file_name }}" required>
        </div>
        <div class="form-group">
            <label for="base_date">Base Date</label>
            <input type="date" name="base_date" class="form-control" value="{{ $ritSubmission->base_date }}" required>
        </div>
        <div class="form-group">
            <label for="status_id">Status ID</label>
            <input type="number" name="status_id" class="form-control" value="{{ $ritSubmission->status_id }}" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
@endsection