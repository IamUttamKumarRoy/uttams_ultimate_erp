@extends('layouts.adminlte_3') 

@section('content')
<div class="container-fluid">
    <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        RIT Submissions
                    </div>
                    <div class="card-body">
                    <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>File Name</th>
                                    <th>Base Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($rit_submissions as $submission)
                                    <tr>
                                        <td>{{ $submission->id }}</td>
                                        <td>{{ $submission->file_name }}</td>
                                        <td>{{ $submission->base_date }}</td>
                                        <td>{{ $submission->status_id }}</td>
                                        <td>
                                            <a href="{{ route('rit-submissions.show', $submission->id) }}" class="btn btn-info">View</a>
                                            <a href="{{ route('rit-submissions.edit', $submission->id) }}" class="btn btn-warning">Edit</a>
                                            <form action="{{ route('rit-submissions.destroy', $submission->id) }}" method="POST" style="display:inline;">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        
                        <div class="card-footer clearfix">
                            {{ $rit_submissions->links() }} {{-- This renders the pagination links --}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    
</div>
@endsection