@extends('layouts.app')

@section('content')
    <h1>Create New Submission</h1>
    <form action="{{ route('rit_submissions.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="file_name">File Name</label>
            <input type="text" name="file_name" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="base_date">Base Date</label>
            <input type="date" name="base_date" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="status_id">Status ID</label>
            <input type="number" name="status_id" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
@endsection