@extends('layouts.app')

@section('content')
    <h1>Bank FI Classes</h1>
    <a href="{{ route('bank-fi-classes.create') }}" class="btn btn-primary">Create New</a>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>FI Class ID</th>
                <th>FI Inst Type</th>
                <th>FI Category</th>
                <th>FI Cluster</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($bankFiClasses as $bankFiClass)
                <tr>
                    <td>{{ $bankFiClass->id }}</td>
                    <td>{{ $bankFiClass->fi_class_id }}</td>
                    <td>{{ $bankFiClass->fi_inst_type }}</td>
                    <td>{{ $bankFiClass->fi_category }}</td>
                    <td>{{ $bankFiClass->fi_cluster }}</td>
                    <td>
                        <a href="{{ route('bank-fi-classes.edit', $bankFiClass->id) }}" class="btn btn-warning">Edit</a>
                        <form action="{{ route('bank-fi-classes.destroy', $bankFiClass->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
