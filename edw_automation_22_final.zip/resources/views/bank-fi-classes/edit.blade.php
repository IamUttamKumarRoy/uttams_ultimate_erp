@extends('layouts.app')

@section('content')
    <h1>Edit Bank FI Class</h1>
    <form action="{{ route('bank-fi-classes.update', $bankFiClass->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div>
            <label>FI Class ID:</label>
            <input type="number" name="fi_class_id" value="{{ $bankFiClass->fi_class_id }}" required>
        </div>
        <div>
            <label>FI Inst Type:</label>
            <input type="text" name="fi_inst_type" value="{{ $bankFiClass->fi_inst_type }}" required>
        </div>
        <div>
            <label>FI Category:</label>
            <input type="text" name="fi_category" value="{{ $bankFiClass->fi_category }}" required>
        </div>
        <div>
            <label>FI Cluster:</label>
            <input type="text" name="fi_cluster" value="{{ $bankFiClass->fi_cluster }}" required>
        </div>
        <button type="submit">Update</button>
    </form>
@endsection
