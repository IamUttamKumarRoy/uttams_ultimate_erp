@extends('layouts.app')

@section('content')
    <h1>Bank FI Class Details</h1>
    <p><strong>FI Class ID:</strong> {{ $bankFiClass->FI_CLASS_ID }}</p>
    <p><strong>FI Inst Type:</strong> {{ $bankFiClass->FI_INST_TYPE }}</p>
    <p><strong>FI Category:</strong> {{ $bankFiClass->FI_CATEGORY }}</p>
    <p><strong>FI Cluster:</strong> {{ $bankFiClass->FI_CLUSTER }}</p>
    <a href="{{ route('bank-fi-classes.index') }}" class="btn btn-secondary">Back</a>
@endsection