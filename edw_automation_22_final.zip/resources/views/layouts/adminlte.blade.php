<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>EDW Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="title" content="EDW Portal | Dashboard" />    
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="icon" type="image/x-icon" href="{{ asset('assets/images/favicon.png') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/overlayscrollbars.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap-icons.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/theme_style.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/app.css') }}" />
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <!-- top navigation panel -->

        <nav class="app-header navbar navbar-expand bg-body">
            <div class="container-fluid">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                            <i class="bi bi-list"></i>
                        </a>
                    </li>
                    <li class="nav-item d-none d-md-block">
                        <div class="app-content-header">
                            <div class="container-fluid">
                                <div class="row">
                                    <h3 class="mb-0">@yield('page_header')</h3>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-lte-toggle="fullscreen">
                            <i data-lte-icon="maximize" class="bi bi-arrows-fullscreen"></i>
                            <i data-lte-icon="minimize" class="bi bi-fullscreen-exit" style="display: none"></i>
                        </a>
                    </li>
                    <li class="nav-item dropdown user-menu">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <span class="d-none d-md-inline">{{ Auth::user()->full_name ?? 'User Name' }}</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
                            <li class="user-header text-bg-primary text-center">
                                <p>
                                    {{ Auth::user()->full_name ?? 'Guest' }}
                                    ({{ Auth::user()->designation ?? 'Designation' }})
                                    <br>
                                    <small>{{ Auth::user()->department ?? 'Department' }},
                                        {{ Auth::user()->fi_branch_id ?? 'FI ID' }}</small>
                                </p>
                            </li>
                            <li class="user-footer d-flex px-3">
                                <a href="#" class="btn btn-outline-primary btn-flat">Profile</a>
                                <form action="{{ route('logout') }}" method="POST" class="ms-auto">
                                    @csrf
                                    <button type="submit" class="btn btn-outline-danger btn-flat">Sign out</button>
                                </form>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- left navigation panel -->
        <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
            <div class="sidebar-brand">
                <a href="{{ route('rit-upload') }}" class="brand-link">
                    <!-- Ensure the image is block-level, and text will be below it -->
                    <div style="text-align: center;"> <!-- Centering the content if needed -->
                        <img src="{{ asset('assets/images/favicon.png') }}" alt="Logo"
                            style="width: 80px; height: auto; display: block; margin: 10px;">
                        <span class="brand-text fw-light" style="display: block;">EDW Portal</span>
                    </div>
                </a>
            </div>

            <div class="sidebar-wrapper">
                <nav class="mt-2">
                    <ul class="nav sidebar-menu flex-column" role="menu" data-lte-toggle="treeview"
                        aria-labelledby="sidebarMenu" data-accordion="false">
                        @if (array_intersect(['rit/upload', 'rit/upload/status'], session('permissions', [])))
                            <li class="nav-header">Dashboard</li>
                        @endif
                        @if (in_array('rit/upload', session('permissions', [])))
                            <li class="nav-item" role="none">
                                <a href="{{ route('rit.upload') }}" class="nav-link" role="menuitem">
                                    <i class="nav-icon bi bi-table"></i>
                                    <p>Upload RIT</p>
                                </a>
                            </li>
                        @endif
                        @if (in_array('rit/upload/status', session('permissions', [])))
                            <li class="nav-item" role="none">
                                <a href="{{ route('rit.upload.status') }}" class="nav-link" role="menuitem">
                                    <i class="nav-icon bi bi-table"></i>
                                    <p>Upload Status</p>
                                </a>
                            </li>
                        @endif
                        @if (array_intersect(['fi', 'fi-branch', 'fi-class'], session('permissions', [])))
                            <li class="nav-header">FI Management</li>
                        @endif
                        @if (in_array('fi', session('permissions', [])))
                            <li class="nav-item" role="none">
                                <a href="{{ route('fi.index') }}" class="nav-link" role="menuitem">
                                    <i class="nav-icon bi bi-table"></i>
                                    <p>FI List</p>
                                </a>
                            </li>
                        @endif
                        @if (in_array('fi-branch', session('permissions', [])))
                            <li class="nav-item" role="none">
                                <a href="{{ route('fi-branch.index') }}" class="nav-link" role="menuitem">
                                    <i class="nav-icon bi bi-patch-check-fill"></i>
                                    <p>FI Branch List</p>
                                </a>
                            </li>
                        @endif
                        @if (in_array('fi-class', session('permissions', [])))
                            <li class="nav-item" role="none">
                                <a href="{{ route('fi-class.index') }}" class="nav-link" role="menuitem">
                                    <i class="nav-icon bi bi-table"></i>
                                    <p>Fi Class List</p>
                                </a>
                            </li>
                        @endif
                        @if (array_intersect(['role', 'permission', 'role-permission'], session('permissions', [])))
                            <li class="nav-header">Permission Management</li>
                        @endif
                        @if (in_array('role', session('permissions', [])))
                            <li class="nav-item" role="none">
                                <a href="{{ route('role.index') }}" class="nav-link" role="menuitem">
                                    <i class="nav-icon bi bi-patch-check-fill"></i>
                                    <p>Role List</p>
                                </a>
                            </li>
                        @endif
                        @if (in_array('permission', session('permissions', [])))
                            <li class="nav-item" role="none">
                                <a href="{{ route('permission.index') }}" class="nav-link" role="menuitem">
                                    <i class="nav-icon bi bi-patch-check-fill"></i>
                                    <p>Permission List</p>
                                </a>
                            </li>
                        @endif
                        @if (in_array('role-permission', session('permissions', [])))
                            <li class="nav-item" role="none">
                                <a href="{{ route('role-permission.index') }}" class="nav-link" role="menuitem">
                                    <i class="nav-icon bi bi-patch-check-fill"></i>
                                    <p>Role-Permission List</p>
                                </a>
                            </li>
                        @endif
                        @if (in_array('user-role', session('permissions', [])))
                            <li class="nav-item" role="none">
                                <a href="{{ route('user-role.index') }}" class="nav-link" role="menuitem">
                                    <i class="nav-icon bi bi-patch-check-fill"></i>
                                    <p>User Role List</p>
                                </a>
                            </li>
                        @endif

                        @if (array_intersect(['user'], session('permissions', [])))
                            <li class="nav-header">User Management</li>
                        @endif
                        @if (in_array('user', session('permissions', [])))
                            <li class="nav-item" role="none">
                                <a href="{{ route('user.index') }}" class="nav-link" role="menuitem">
                                    <i class="nav-icon bi bi-patch-check-fill"></i>
                                    <p>User List</p>
                                </a>
                            </li>
                        @endif
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- main content, will be updated on child views -->
        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid">
                    <br />
                    <div class="row">
                        <div>
                            <div id="message-container">
                                @if (session('success'))
                                    <div class="alert alert-success" role="alert" style="padding-left: 2%">
                                        {{ session('success') }}
                                    </div>
                                @endif

                                <!-- Error Message -->
                                @if (session('error'))
                                    <div class="alert alert-danger" role="alert" style="padding-left: 2%">
                                        {{ session('error') }}
                                    </div>
                                @endif

                                <!-- Validation Errors -->
                                @if (session('errors') && session('errors')->any())
                                    <ul class="alert alert-danger" role="alert" style="padding-left: 2%">
                                        @foreach (session('errors')->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif
                            </div>
                        </div>

                        @yield('content')

                    </div>
                </div>
            </div>
        </main>

        <footer class="app-footer fs-6">
            Copyright &copy; Information and Communication Technology
            Department,&nbsp; Bangladesh Bank
        </footer>
    </div>

    <script src="{{ asset('assets/js/overlayscrollbars.browser.es6.min.js') }}"></script>
    <script src="{{ asset('assets/js/popper.min.js') }}"></script>
    <script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('assets/js/theme.js') }}"></script>
    <script src="{{ asset('assets/js/theme_sidebar_wrapper.js') }}"></script>
    <script src="{{ asset('assets/js/app.js') }}"></script>
</body>

</html>
