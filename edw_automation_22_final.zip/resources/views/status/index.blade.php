<!DOCTYPE html>
<html>
<head>
    <title>Statuses</title>
</head>
<body>
    <h1>Statuses</h1>
    <a href="{{ route('status.create') }}">Create New Status</a>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Detail</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($statuses as $status)
                <tr>
                    <td>{{ $status->id }}</td>
                    <td>{{ $status->name }}</td>
                    <td>{{ $status->detail }}</td>
                    <td>
                        <a href="{{ route('status.show', $status->id) }}">View</a>
                        <a href="{{ route('status.edit', $status->id) }}">Edit</a>
                        <form action="{{ route('status.destroy', $status->id) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>