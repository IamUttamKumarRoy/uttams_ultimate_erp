<!DOCTYPE html>
<html>
<head>
    <title>Create Status</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Create Status</h1>
        <form action="{{ route('status.store') }}" method="POST">
            @csrf
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="detail" class="form-label">Detail</label>
                <textarea name="detail" class="form-control"></textarea>
            </div>
            <div class="mb-3">
                <label for="sorting_order" class="form-label">Sorting Order</label>
                <input type="number" name="sorting_order" class="form-control">
            </div>
            <div class="mb-3">
                <label for="terminal" class="form-label">Terminal</label>
                <input type="text" name="terminal" class="form-control">
            </div>
            <div class="mb-3">
                <label for="browser" class="form-label">Browser</label>
                <input type="text" name="browser" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>