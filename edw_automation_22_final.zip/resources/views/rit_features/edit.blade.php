@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Edit RIT Feature</h1>
    <form action="{{ route('rit-features.update', $ritFeature->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="rit_id">RIT ID</label>
            <input type="number" name="rit_id" class="form-control" value="{{ $ritFeature->rit_id }}" required>
        </div>
        <div class="form-group">
            <label for="rit_name">Name</label>
            <input type="text" name="rit_name" class="form-control" value="{{ $ritFeature->rit_name }}" required>
        </div>
        <div class="form-group">
            <label for="rit_freq">Frequency</label>
            <input type="text" name="rit_freq" class="form-control" value="{{ $ritFeature->rit_freq }}" required>
        </div>
        <div class="form-group">
            <label for="rit_version">Version</label>
            <input type="number" name="rit_version" class="form-control" value="{{ $ritFeature->rit_version }}" required>
        </div>
        <div class="form-group">
            <label for="no_of_col">Number of Columns</label>
            <input type="number" name="no_of_col" class="form-control" value="{{ $ritFeature->no_of_col }}" required>
        </div>
        <div class="form-group">
            <label for="no_of_row">Number of Rows</label>
            <input type="number" name="no_of_row" class="form-control" value="{{ $ritFeature->no_of_row }}" required>
        </div>
        <div class="form-group">
            <label for="cut_off_days">Cut-off Days</label>
            <input type="number" name="cut_off_days" class="form-control" value="{{ $ritFeature->cut_off_days }}" required>
        </div>
        <div class="form-group">
            <label for="dept">Department</label>
            <input type="text" name="dept" class="form-control" value="{{ $ritFeature->dept }}" required>
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <input type="text" name="status" class="form-control" value="{{ $ritFeature->status }}" required>
        </div>
        <div class="form-group">
            <label for="validate">Validate</label>
            <input type="number" name="validate" class="form-control" value="{{ $ritFeature->validate }}" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
@endsection