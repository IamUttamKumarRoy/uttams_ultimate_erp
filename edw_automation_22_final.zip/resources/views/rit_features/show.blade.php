@extends('layouts.app')

@section('content')
<div class="container">
    <h1>RIT Feature Details</h1>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">{{ $ritFeature->rit_name }}</h5>
            <p class="card-text"><strong>RIT ID:</strong> {{ $ritFeature->rit_id }}</p>
            <p class="card-text"><strong>Frequency:</strong> {{ $ritFeature->rit_freq }}</p>
            <p class="card-text"><strong>Version:</strong> {{ $ritFeature->rit_version }}</p>
            <p class="card-text"><strong>Department:</strong> {{ $ritFeature->dept }}</p>
            <p class="card-text"><strong>Status:</strong> {{ $ritFeature->status }}</p>
            <a href="{{ route('rit-features.edit', $ritFeature->id) }}" class="btn btn-warning">Edit</a>
            <form action="{{ route('rit-features.destroy', $ritFeature->id) }}" method="POST" style="display:inline;">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
        </div>
    </div>
</div>
@endsection