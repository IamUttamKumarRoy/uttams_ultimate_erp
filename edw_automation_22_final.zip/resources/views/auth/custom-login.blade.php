@if ($errors->any())
    <div>
        @foreach ($errors->all() as $error)
            <p style="color: red;">{{ $error }}</p>
        @endforeach
    </div>
@endif
<form method="POST" action="{{ route('custom.login.submit') }}">
    @csrf
    <label>User ID:</label>
    <input type="text" name="user_id" >
    
    <label>Password:</label>
    <input type="password" name="password" >

    <button type="submit">Login</button>
</form>