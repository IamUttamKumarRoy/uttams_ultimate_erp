<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <meta name="csrf-token" content="{{ csrf_token() }}"> 
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/font/bootstrap-icons.css">


    <style>
      .login-box, .register-box {
        width: 360px;
        margin: 7% auto;
      }

      .notice-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 0.5rem; /* Equivalent to me-2 */
  }
  .dot-red { background-color: red; }
  .dot-blue { background-color: blue; }
  .dot-green { background-color: green; }
  .dot-orange { background-color: orange; }

  .captcha-image {
    display: block;
    /*margin: 10px auto;*/
    border-radius: 5px;
    border: 2px solid #ddd;
}
    </style>
  </head>
  <body>


<!-- <div class="container text-center" style="height: 5px; background-color: green;"></div> -->
<!-- <section class="h-100 gradient-form" style="background-color: #eee;"> -->
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-xl-10">
        <div class="card rounded-3 text-black">
          <div class="row g-0">
            <div class="col-lg-6">
              <div class="login-box">
                <div class="img-responsive">
                  <img class="img-responsive" src="assets/logo1.jpg" height=" ">
                </div>
                <div class="login-box-body">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                  <p class="login-box-msg">
                    <font color="blue">
                      <b>Enter User ID and Password</b>
                    </font>
                  </p>
                  
                  <form method="POST" action="{{ route('lab.login-post') }}" class="bg-white p-6 rounded-lg shadow-md">
                    @csrf  
                      <!-- Username Field -->
                      <div class="mb-3">
                          <!-- <label for="user_id" class="form-label">Username</label> -->
                          <div class="input-group">
                              <input type="text" class="form-control" name="user_id" id="user_id" placeholder="User ID">
                              <span class="input-group-text">
                                  <i class="bi bi-person"></i>
                              </span>
                          </div>
                      </div>

                      <!-- Password Field -->
                      <div class="mb-3">
                          <!-- <label for="password" class="form-label">Password</label> -->
                          <div class="input-group">
                              <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password">
                              <span class="input-group-text">
                                  <i class="bi bi-lock"></i>
                              </span>
                          </div>
                      </div>

                      <!-- CAPTCHA Field -->
                      <div class="mb-3">                          
                          <img src="{{ url('captcha') }}" alt="Captcha" class="captcha-image img-fluid mb-2">
                          <label for="captcha" class="form-label text-first"><b>Enter the text from the image above</b></label>
                          <input type="text" name="captcha" class="form-control" id="captcha" placeholder="Insert the word above">
                      </div>

                      <!-- Login Button -->
                      <div class="d-flex justify-content-end">
                          <button type="submit" class="btn btn-primary">Login</button>
                      </div>
                      <!-- Register Link -->
                      <div class="mb-3 text-first">
                          Don't Have User ID? <a href="register.html" class="text-decoration-none">Register</a>
                      </div>
                  </form>
                   
                  <!-- /.login-box-body -->
                </div>
                <!-- /.login-box -->
              </div>
            </div>
            <!-- <div class="col-lg-6 d-flex align-items-center bg-warning text-dark p-4"> -->
            <div class="col-lg-6 d-flex align-items-center p-4">
              <div>
                <h5 class="mb-3">Important Notices</h5>
                <ul class="list-group list-group-flush">
                  <li class="list-group-item d-flex align-items-center">
                    <span class="notice-dot dot-orange"></span>                    
                    <font size="3" color="red">
                      <b> ** Do not upload ISS form-3 and 4 until further instruction is given from integrated Supervision Management Department of Bangladesh Bank .
                      </b> 
                    </font>
                  </li>
                  <li class="list-group-item d-flex align-items-center">
                   <span class="notice-dot dot-orange"></span>
                    <font size="3" color="red">
                    <b> Branches of Banks and NBFIs are requested to contact with their respective Head office admin if they face any problem while uploading data.</b> 
                    </font>
                  </li>
                  <li class="list-group-item d-flex align-items-center">
                    <span class="notice-dot dot-orange"></span>
                    <font size="3">
                    For uploading any csv file, Banks and NBFIs have to download the required <b>RITs</b> and updated <b>Reference File</b> from this Web Portal.
                    </font>
                  </li>
                  <li class="list-group-item d-flex align-items-center">
                    <span class="notice-dot dot-orange"></span>
                    <font size="3" color="green">
                      For technical problem please contact to: <b>support.edw@bb.org.bd </b>
                    </font>
                  </li>
                </ul>
              </div>
            </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<!-- </section> -->
    <script src="assets/bootstrap/js/bootstrap.bundle.min.js" ></script>
  </body>
</html>

