@extends('layouts.app')

@section('content')
    <h1>Create Role</h1>
    <form action="{{ route('roles.store') }}" method="POST">
        @csrf
        <div>
            <label>Role ID:</label>
            <input type="number" name="role_id" required>
        </div>
        <div>
            <label>Name:</label>
            <input type="text" name="name" required>
        </div>
        <div>
            <label>Status ID:</label>
            <input type="number" name="status_id" required>
        </div>
        <button type="submit">Create</button>
    </form>
@endsection