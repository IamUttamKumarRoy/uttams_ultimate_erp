@extends('layouts.adminlte_3') 

@section('content')

<div class="container-fluid">
    <div class="row">
      <!-- left column -->
        <div class="col-md-12">
            <h1>Roles</h1>
            <a href="{{ route('roles.create') }}" class="btn btn-primary">Create New</a>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Role ID</th>
                        <th>Name</th>
                        <th>Status ID</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($roles as $role)
                        <tr>
                            <td>{{ $role->id }}</td>
                            <td>{{ $role->role_id }}</td>
                            <td>{{ $role->name }}</td>
                            <td>{{ $role->status_id }}</td>
                            <td>
                                <a href="{{ route('roles.edit', $role->id) }}" class="btn btn-warning">Edit</a>
                                 <a href="{{ route('roles.permissions', $role->id) }}" class="btn btn-primary btn-sm">AssignP</a>
                                <form action="{{ route('roles.destroy', $role->id) }}" method="POST" style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection