@extends('layouts.adminlte_3')

@section('title', 'Admin Lte Dashboard')

@section('content')
    <h1>Welcome to EDW</h1>
    
@endsection