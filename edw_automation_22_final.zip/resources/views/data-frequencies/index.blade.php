@extends('layouts.app')

@section('content')
    <h1>Data Frequencies</h1>
    <a href="{{ route('data-frequencies.create') }}" class="btn btn-primary">Create New</a>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Short Name</th>
                <th>Full Name</th>
                <th>Description</th>
                <th>Status ID</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($dataFrequencies as $dataFrequency)
                <tr>
                    <td>{{ $dataFrequency->id }}</td>
                    <td>{{ $dataFrequency->short_name }}</td>
                    <td>{{ $dataFrequency->full_name }}</td>
                    <td>{{ $dataFrequency->description }}</td>
                    <td>{{ $dataFrequency->status_id }}</td>
                    <td>
                        <a href="{{ route('data-frequencies.edit', $dataFrequency->id) }}" class="btn btn-warning">Edit</a>
                        <form action="{{ route('data-frequencies.destroy', $dataFrequency->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection