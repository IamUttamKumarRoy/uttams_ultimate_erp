@extends('layouts.app')

@section('content')
    <h1>Create Data Frequency</h1>
    <form action="{{ route('data-frequencies.store') }}" method="POST">
        @csrf
        <div>
            <label>Short Name:</label>
            <input type="text" name="short_name" required>
        </div>
        <div>
            <label>Full Name:</label>
            <input type="text" name="full_name" required>
        </div>
        <div>
            <label>Description:</label>
            <textarea name="description"></textarea>
        </div>
        <div>
            <label>Status ID:</label>
            <input type="number" name="status_id">
        </div>
        <button type="submit">Create</button>
    </form>
@endsection