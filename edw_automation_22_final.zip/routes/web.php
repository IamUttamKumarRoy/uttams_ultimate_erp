<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Session;

// import controllers 
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\EdwLoginController;
use App\Http\Controllers\CaptchaController;

use App\Http\Controllers\MigrationController;
use App\Http\Controllers\CsvController;
use App\Http\Controllers\CustomLoginController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\DataFrequencyController;
use App\Http\Controllers\BankFiClassController;
use App\Http\Controllers\RitFeatureController;
use App\Http\Controllers\RitSubmissionController;
use App\Http\Controllers\LoginAttemptController;
use App\Http\Controllers\RndLabController;
use App\Http\Controllers\FileController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\LabController;
use App\Http\Controllers\BankBranchController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\PermissionController;

// Route caching enabled (Remember to run `php artisan route:cache`)

// Landing Page 
//Route::get('/', function () {
//    return view('welcome');
//});

Route::get('/', [DashboardController::class, 'bankBranchEndDashboard'])->name('home')->middleware('auth'); 

Route::get('dashboard', [DashboardController::class, 'bankBranchEndDashboard'])->name('dashboard')->middleware('auth'); 
//Route::get('dashboard', [DashboardController::class, 'bankBranchEndDashboard'])->name('dashboard')->middleware('auth'); 

Route::get('sync-permissions', [PermissionController::class, 'syncPermissions'])->name('sync.permissions');
Route::get('add-permissions', [PermissionController::class, 'addRoutes'])->name('permission.add');

// routes/web.php
Route::get('roles/{role}/permissions', [RoleController::class, 'editPermissions'])
    ->name('roles.permissions');
Route::post('roles/{role}/permissions', [RoleController::class, 'updatePermissions'])
    ->name('roles.update-permissions');

Route::resource('permissions', PermissionController::class);
Route::resource('departments', DepartmentController::class);
Route::resource('data-frequencies', DataFrequencyController::class);
Route::resource('bank-fi-classes', BankFiClassController::class);
Route::resource('rit-features', RitFeatureController::class);
Route::resource('rit-submissions', RitSubmissionController::class);
Route::resource('login-attempts', LoginAttemptController::class);
Route::resource('roles', RoleController::class);

// To generate captcha in the login form
Route::get('/captcha', [CaptchaController::class, 'generate']);

// Login 
Route::get('login', [EdwLoginController::class, 'loginForm'])->name('login');
Route::post('login', [EdwLoginController::class, 'login'])->name('edw.login-submit');
Route::get('logout', [EdwLoginController::class, 'logout'])->name('logout');

Route::get('register-user', [EdwLoginController::class, 'registerForm'])->name('edw.register');
Route::post('register-user', [EdwLoginController::class, 'registration'])->name('edw.register-post');

Route::get('sbs-code-user-limit', [EdwLoginController::class, 'sbsCodeUserLimit'])->name('sbs_code.user_limit_check');


// User related
Route::resource('users', UserController::class);
Route::get('change-password', [EdwLoginController::class, 'showChangePasswordForm'])->name('change.password.get')->middleware('auth'); 
Route::post('change-password', [EdwLoginController::class, 'submitChangePasswordForm'])->name('change.password.post')->middleware('auth'); 
Route::get('profile', [UserController::class, 'profile'])->name('users.profile');
Route::get('blocked_userlist', [UserController::class, 'blockedUserlist'])->name('users.blocked_userlist');
Route::get('inactive_userlist', [UserController::class, 'inactiveUserlist'])->name('users.inactive_userlist');
Route::get('admin_userlist', [UserController::class, 'adminUserList'])->name('users.admin_userlist');
Route::get('active_userlist', [UserController::class, 'activeUserList'])->name('users.active_userlist');

Route::get('add-md', [UserController::class, 'addMdForm'])->name('users.add-md');
Route::post('add-md', [UserController::class, 'addMdUser'])->name('users.add-md-user');

Route::get('/home', [PageController::class, 'home'])->name('home');
Route::get('/about', [PageController::class, 'about'])->name('about');
Route::get('/contact', [PageController::class, 'contact'])->name('contact');

// Upload status 
Route::get('upload-status', [ReportController::class, 'uploadStatus'])->name('report.upload-status');
Route::post('upload-status', [ReportController::class, 'uploadStatus'])->name('report.upload-status');

Route::get('upload-status-rit', [ReportController::class, 'uploadStatusByRit'])->name('report.upload-status-rit');
Route::post('upload-status-rit', [ReportController::class, 'uploadStatusByRit'])->name('report.upload-status-rit');

Route::get('non-reporting-branches', [ReportController::class, 'nonReportingBranch'])->name('report.non-reporting-branches');
Route::post('non-reporting-branches', [ReportController::class, 'nonReportingBranch'])->name('report.non-reporting-branches');


Route::get('non-reporting-bank', [ReportController::class, 'nonReportingBank'])->name('report.non-reporting-bank');
Route::post('non-reporting-bank', [ReportController::class, 'nonReportingBank'])->name('report.non-reporting-bank');

Route::get('import-branch', [BankBranchController::class, 'importBranch'])->name('import.import-branch');
Route::post('import-branch', [BankBranchController::class, 'importBranchPost'])->name('import.import-branch-post');

Route::get('download-rit', [RitSubmissionController::class, 'downloadRit'])->name('rit.download-rit');
Route::get('/download/{department}/{filename}', [RitSubmissionController::class, 'downloadFile'])->name('file.download');
/*Route::get('/download/{filename}', function ($filename) {
    $filePath = public_path('your-folder/' . $filename);
    return response()->download($filePath);
})->name('file.download');
*/
Route::post('/get-frequencies', [RitSubmissionController::class, 'getFrequencies'])->name('get.frequency');
Route::post('/get-bank-branches', [RitSubmissionController::class, 'getBankBranches'])->name('get.branches');

Route::post('/get-branches-by-bank', [RitSubmissionController::class, 'getBranchesByBank'])->name('ajax.get-branches-by-bank');
Route::post('/get-user-id', [RitSubmissionController::class, 'getUserCount'])->name('ajax.get-user-id');

//Route::post('/download-rit', [RitSubmissionController::class, 'downloadRit'])->name('rit.download');

Route::get('/import', [LabController::class, 'importForm'])->name('import.form');
Route::post('/import', [LabController::class, 'import'])->name('import');

Route::get('update-bank-class', [MigrationController::class, 'migrateBankFiClassForm'])->name('migrations.update-bank-class');
Route::post('update-bank-class', [MigrationController::class, 'migrateBankFiClassPost'])->name('migrations.update-bank-class-post');

// Report Routes
// File Upload Routes
// Authentication Routes