# Aether Folder-Based Page Checklist

## Root — 1 Pages

- [x] `dashboard.html`

## Dashboards — 10 Pages

- [x] `dashboards/dashboard-aether-production.html`
- [x] `dashboards/dashboard-analytics.html`
- [x] `dashboards/dashboard-crm.html`
- [x] `dashboards/dashboard-ecommerce.html`
- [x] `dashboards/dashboard-marketing.html`
- [x] `dashboards/dashboard-projects.html`
- [x] `dashboards/dashboard-aether-nosidebar.html`
- [x] `dashboards/dashboard-dark.html`
- [x] `dashboards/dashboard-minimal.html`
- [x] `dashboards/dashboard-rtl.html`

## Auth — 12 Pages

- [x] `auth/login.html`
- [x] `auth/register.html`
- [x] `auth/forgot-password.html`
- [x] `auth/reset-password.html`
- [x] `auth/email-verification.html`
- [x] `auth/two-factor-auth.html`
- [x] `auth/lock-screen.html`
- [x] `auth/social-login.html`
- [x] `auth/otp-verification.html`
- [x] `auth/password-strength.html`
- [x] `auth/auth-split-layout.html`
- [x] `auth/auth-dark.html`

## Errors — 7 Pages

- [x] `errors/error-403.html`
- [x] `errors/error-404.html`
- [x] `errors/error-500.html`
- [x] `errors/maintenance-mode.html`
- [x] `errors/coming-soon.html`
- [x] `errors/offline.html`
- [x] `errors/under-construction.html`

## Security — 8 Pages

- [x] `security/access-control.html`
- [x] `security/activity-log.html`
- [x] `security/audit-reports.html`
- [x] `security/compliance-gdpr.html`
- [x] `security/security-logs.html`
- [x] `security/system-status.html`
- [x] `security/permission-matrix.html`
- [x] `security/role-management.html`

## Users — 10 Pages

- [x] `users/create-user.html`
- [x] `users/edit-user.html`
- [x] `users/invite-user.html`
- [x] `users/organization-members.html`
- [x] `users/user-activity.html`
- [x] `users/user-details.html`
- [x] `users/user-grid.html`
- [x] `users/user-list.html`
- [x] `users/user-profile.html`
- [x] `users/user-sessions.html`

## Roles — 3 Pages

- [x] `roles/create-role.html`
- [x] `roles/role-details.html`
- [x] `roles/roles-permissions.html`

## Ecommerce — 12 Pages

- [x] `ecommerce/ecommerce-dashboard.html`
- [x] `ecommerce/orders.html`
- [x] `ecommerce/pricing-plans.html`
- [x] `ecommerce/invoice.html`
- [x] `ecommerce/subscription-confirmed.html`
- [x] `ecommerce/products.html`
- [x] `ecommerce/product-details.html`
- [x] `ecommerce/add-product.html`
- [x] `ecommerce/customers.html`
- [x] `ecommerce/cart.html`
- [x] `ecommerce/checkout.html`
- [x] `ecommerce/wishlist.html`

## Communication — 10 Pages

- [x] `communication/communication-dashboard.html`
- [x] `communication/message-inbox.html`
- [x] `communication/newsletter-management.html`
- [x] `communication/team-collaboration.html`
- [x] `communication/chat.html`
- [x] `communication/video-meeting.html`
- [x] `communication/notifications.html`
- [x] `communication/contacts.html`
- [x] `communication/group-chat.html`
- [x] `communication/voice-call.html`

## Monitoring — 7 Pages

- [x] `monitoring/monitoring-dashboard.html`
- [x] `monitoring/performance-monitoring.html`
- [x] `monitoring/server-health.html`
- [x] `monitoring/transactions.html`
- [x] `monitoring/uptime-reports.html`
- [x] `monitoring/logs-viewer.html`
- [x] `monitoring/sla-tracking.html`

## Data Tables — 7 Pages

- [x] `data-tables/tables.html`
- [x] `data-tables/tables-all.html`
- [x] `data-tables/search-results.html`
- [x] `data-tables/datatables-advanced.html`
- [x] `data-tables/export-tables.html`
- [x] `data-tables/pivot-tables.html`
- [x] `data-tables/data-grid.html`

## Charts — 8 Pages

- [x] `charts/charts-line.html`
- [x] `charts/charts-bar.html`
- [x] `charts/charts-pie.html`
- [x] `charts/charts-heatmap.html`
- [x] `charts/charts-radial.html`
- [x] `charts/charts-candlestick.html`
- [x] `charts/charts-mixed.html`
- [x] `charts/charts-dashboard.html`

## Forms — 8 Pages

- [x] `forms/forms-basic.html`
- [x] `forms/forms-wizard.html`
- [x] `forms/forms-editors.html`
- [x] `forms/forms-file-upload.html`
- [x] `forms/forms-validation.html`
- [x] `forms/forms-advanced.html`
- [x] `forms/forms-layouts.html`
- [x] `forms/forms-dark.html`

## Projects — 6 Pages

- [x] `projects/project-management.html`
- [x] `projects/project-kanban.html`
- [x] `projects/project-calendar.html`
- [x] `projects/project-dashboard.html`
- [x] `projects/project-tasks.html`
- [x] `projects/project-reports.html`

## Productivity — 8 Pages

- [x] `productivity/file-manager.html`
- [x] `productivity/email-compose.html`
- [x] `productivity/email-read.html`
- [x] `productivity/email-starred.html`
- [x] `productivity/email-trash.html`
- [x] `productivity/notes.html`
- [x] `productivity/task-manager.html`
- [x] `productivity/productivity-dashboard.html`

## Marketing — 6 Pages

- [x] `marketing/landing-page.html`
- [x] `marketing/testimonials.html`
- [x] `marketing/contact.html`
- [x] `marketing/features.html`
- [x] `marketing/pricing.html`
- [x] `marketing/marketing-dashboard.html`

## Legal — 2 Pages

- [x] `legal/privacy-policy.html`
- [x] `legal/terms.html`

## Ui — 30 Pages

- [x] `ui/ui-overview.html`
- [x] `ui/ui-accordions.html`
- [x] `ui/ui-alerts.html`
- [x] `ui/ui-avatars.html`
- [x] `ui/ui-badges.html`
- [x] `ui/ui-breadcrumbs.html`
- [x] `ui/ui-buttons.html`
- [x] `ui/ui-cards.html`
- [x] `ui/ui-carousel.html`
- [x] `ui/ui-dropdowns.html`
- [x] `ui/ui-empty-states.html`
- [x] `ui/ui-forms.html`
- [x] `ui/ui-icons.html`
- [x] `ui/ui-input-groups.html`
- [x] `ui/ui-list-groups.html`
- [x] `ui/ui-modals.html`
- [x] `ui/ui-navs.html`
- [x] `ui/ui-offcanvas.html`
- [x] `ui/ui-pagination.html`
- [x] `ui/ui-popovers.html`
- [x] `ui/ui-progress.html`
- [x] `ui/ui-spinners.html`
- [x] `ui/ui-tables.html`
- [x] `ui/ui-tabs.html`
- [x] `ui/ui-timelines.html`
- [x] `ui/ui-toasts.html`
- [x] `ui/ui-tooltips.html`
- [x] `ui/ui-typography.html`
- [x] `ui/ui-utilities.html`
- [x] `ui/ui-widgets.html`

## Docs — 7 Pages

- [x] `docs/installation.html`
- [x] `docs/customization.html`
- [x] `docs/changelog.html`
- [x] `docs/credits.html`
- [x] `docs/folder-structure.html`
- [x] `docs/plugin-guide.html`
- [x] `docs/theme-guide.html`


Canonical pages: **162**
Compatibility redirects: **5**
Index redirect: **1**