# Auth CSS Final Update

Updated the template to use the final premium CSS architecture for auth pages.

## Completed

- Merged `assets/css/auth/auth-structure.css` into `assets/css/dashboard.css`.
- Scoped merged auth structure selectors under `body.auth-body` to avoid global dashboard side effects.
- Merged `assets/css/auth/auth-pages.css` into `assets/css/dashboard.css`.
- Updated auth/error HTML files to load `theme.css`, `app.css`, and `pages.css` instead of separate auth CSS files.
- Added `auth-body` to auth page `<body>` elements.
- Archived original auth files under `assets/css/source/auth/`.
- Removed active `assets/css/auth/` from production assets.

## Updated HTML files

19 HTML files were updated.

```text
auth/auth-dark.html
auth/auth-split-layout.html
auth/email-verification.html
auth/forgot-password.html
auth/lock-screen.html
auth/login.html
auth/otp-verification.html
auth/password-strength.html
auth/register.html
auth/reset-password.html
auth/social-login.html
auth/two-factor-auth.html
errors/coming-soon.html
errors/error-403.html
errors/error-404.html
errors/error-500.html
errors/maintenance-mode.html
errors/offline.html
errors/under-construction.html
```

## Additional patch

Added `auth-body` to auth and error page body tags so the scoped merged auth rules apply correctly.
