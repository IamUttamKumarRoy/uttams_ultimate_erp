# Aether 288px ThemeForest Production Update

## Updated files

- `assets/css/theme.css`
  - Sidebar width updated to `288px`.
  - Collapsed mini sidebar width updated to `80px`.

- `assets/css/dashboard.css`
  - Added a production override layer for the 288px enterprise sidebar.
  - Fixed hover and active border clipping.
  - Converted desktop collapsed sidebar into a premium 80px icon rail.
  - Preserved mobile offcanvas behavior.
  - Improved sidebar footer, submenu, focus, and dashboard card polish.

## Recommended load order

```html
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/theme.css" rel="stylesheet">
<link href="assets/css/dashboard.css" rel="stylesheet">
<link href="assets/css/dashboard.css" rel="stylesheet">
```

## Final sidebar standard

```css
:root {
  --auk-sidebar-width: 288px;
  --auk-sidebar-mini-width: 80px;
}
```

This is suitable for a premium ThemeForest / enterprise Bootstrap 5 dashboard because it balances content space, readable long menu labels, icons, badges, chevrons, active states, and collapsed desktop navigation.
