# Aether 288px Production Final Update

## Summary
This package has been updated for a premium ThemeForest / enterprise dashboard sidebar standard using a 288px expanded sidebar and 80px mini sidebar.

## Updated Tokens
```css
--auk-sidebar-width: 288px;
--auk-sidebar-mini-width: 80px;
```

## Sidebar CSS Fix
The sidebar menu item width is intentionally reduced inside the 288px rail:

```css
width: calc(100% - var(--auk-sidebar-item-omit));
margin: 0 var(--auk-sidebar-item-gap) 5px;
```

This prevents hover and active borders from clipping while keeping the sidebar itself at the enterprise-standard 288px width.

## Active Menu Style
The active sidebar style follows the attached app.css reference:

- Accent text color
- Soft accent gradient background
- Accent border
- Inset 3px left active line
- Subtle accent shadow
- No horizontal transform on hover or active

## JavaScript Bundle Update
Dashboard JS has been unified into:

```html
<script src="assets/js/dashboard.js"></script>
```

Auth page JS has been unified into:

```html
<script defer src="../assets/js/auth.js"></script>
```

Bootstrap remains loaded separately because it is a vendor dependency.

## Files Updated
- `assets/css/theme.css`
- `assets/css/dashboard.css`
- `assets/js/dashboard.js`
- `assets/js/auth.js`
- All dashboard/admin HTML script references
- All auth HTML script references
- Documentation references

## Validation
- CSS brace balance checked.
- Duplicate mid-file `@charset` removed from app.css.
- `node --check` passed for both new JS bundles.
- Old dashboard JS references removed from HTML pages.
