Aether Admin Merged Template Pack

Included pages:

Dashboard:
- dashboard.html — Dashboard Overview

CRM:
- crm/leads.html — Leads
- crm/lead-details.html — Lead Details
- crm/deals.html — Deals
- crm/deal-details.html — Deal Details
- crm/pipeline.html — Pipeline
- crm/customers.html — Customers
- crm/customer-details.html — Customer Details
- crm/activities.html — Activities
- crm/reports.html — Reports

Ecommerce:
- ecommerce/inventory.html — Inventory
- ecommerce/coupons.html — Coupons
- ecommerce/refunds.html — Refunds
- ecommerce/returns.html — Returns
- ecommerce/shipping.html — Shipping
- ecommerce/payment-methods.html — Payment Methods
- ecommerce/product-reviews.html — Product Reviews
- ecommerce/order-details.html — Order Details
- ecommerce/customer-details.html — Customer Details

Support / Helpdesk:
- support/help-center.html — Help Center
- support/faq.html — FAQ
- support/support-tickets.html — Support Tickets
- support/ticket-details.html — Ticket Details
- support/create-ticket.html — Create Ticket
- support/knowledge-base.html — Knowledge Base

Blog / CMS:
- blog/blog-list.html — Blog List
- blog/blog-grid.html — Blog Grid
- blog/blog-details.html — Blog Details
- blog/create-post.html — Create Post
- blog/edit-post.html — Edit Post
- blog/categories.html — Categories
- blog/comments.html — Comments

File / Media:
- media/media-library.html — Media Library
- media/upload-files.html — Upload Files
- media/file-details.html — File Details

Billing:
- billing/invoices.html — Invoices
- billing/invoice-details.html — Invoice Details
- billing/create-invoice.html — Create Invoice
- billing/payment-history.html — Payment History
- billing/subscriptions.html — Subscriptions
- billing/subscription-details.html — Subscription Details
- billing/billing-plans.html — Billing Plans

System / Developer:
- developer/api-documentation.html — API Documentation
- developer/api-keys.html — API Keys
- developer/webhooks.html — Webhooks
- developer/error-logs.html — Error Logs
- developer/system-info.html — System Info
- developer/version-control.html — Version Control

Merged from:
- aether-support-helpdesk-pages.zip
- aether-crm-inner-pages.zip
- aether-ecommerce-advanced-pages.zip
- aether-blog-cms-pages.zip
- aether-media-pages.zip
- aether-billing-advanced-pages.zip
- aether-developer-pages.zip

Notes:
- Replace assets/css/theme.css with your original theme.css if your production template has a fuller theme token file.
- Shared dashboard behavior lives in assets/js/dashboard.js.
- Module-specific styles are kept as separate CSS layers to avoid conflicts.