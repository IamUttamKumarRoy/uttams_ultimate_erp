# CSS Architecture Update

Updated on: 2026-07-01 05:55 UTC

## What changed

1. Created `assets/css/dashboard.css` by merging:
   - `assets/css/core/production-ready.css`
   - `assets/css/core/aether-polish.css`

2. Created `assets/css/dashboard.css` by merging all page-pack CSS files from `assets/css/pages/`.

3. Added shared reusable page primitives at the top of `pages.css`:
   - `.aether-surface`
   - `.aether-card`
   - `.aether-title`
   - `.aether-subtitle`
   - `.aether-grid-2`
   - `.aether-grid-3`
   - `.aether-grid-4`
   - `.aether-grid-auto`
   - `.aether-stat-card`

4. Updated 191 HTML files to load:

```html
<link href=".../assets/css/theme.css" rel="stylesheet"/>
<link href=".../assets/css/dashboard.css" rel="stylesheet"/>
<link href=".../assets/css/dashboard.css" rel="stylesheet"/>
```

5. Preserved original separated CSS files in:

```text
assets/css/source/legacy-core/
assets/css/source/page-packs/
```

6. Added `dist/css/aether.min.css` as a combined minified production option.

## Notes

Authentication pages were left on their separate auth CSS stack because they use a different structure and do not need the admin page-pack CSS.
