# Aether CSS Structure

The template now uses three custom CSS files plus vendor CSS:

1. `assets/css/theme.css` — universal design tokens, root variables, theme palettes, and Bootstrap variable mapping. Load this on both dashboard and auth pages.
2. `assets/css/dashboard.css` — dashboard shell, sidebar, header, footer, components, legacy dashboard layout fixes, and all dashboard page-section styles.
3. `assets/css/auth.css` — authentication, error, maintenance, coming-soon, offline, under-construction, and other utility page styles.

Recommended dashboard order:

```html
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/theme.css" rel="stylesheet">
<link href="assets/css/dashboard.css" rel="stylesheet">
```

Recommended auth/utility order:

```html
<link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/theme.css" rel="stylesheet">
<link href="../assets/css/auth.css" rel="stylesheet">
```

The old `core/app.css` and `pages/pages.css` files were merged into `dashboard.css` and `auth.css` so each page type has one structural/page stylesheet.
