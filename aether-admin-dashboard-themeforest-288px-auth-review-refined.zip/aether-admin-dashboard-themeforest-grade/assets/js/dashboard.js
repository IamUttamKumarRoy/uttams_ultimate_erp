/* ========================================================================
   Aether Dashboard JS
   Unified dashboard structural and page interactions.
   Combines the former dashboard bundle, page helpers, sidebar, command palette,
   theme controls, header tools, toasts, forms, and dashboard utilities.
======================================================================== */
(function () {
  'use strict';

  var root = document.documentElement;
  var THEME_MODES = {
    light: 'light', dark: 'dark', obsidian: 'dark', vercel: 'dark', 'deep-space': 'dark', netflix: 'dark',
    microsoft: 'light', google: 'light', apple: 'light', vscode: 'dark', aws: 'dark', royal: 'light',
    spotify: 'dark', figma: 'light', slack: 'light', airbnb: 'light', uber: 'dark', sapphire: 'light',
    nebula: 'dark', aurora: 'light', phoenix: 'light', sakura: 'light', sunset: 'light', rose: 'light',
    slate: 'light', emerald: 'light', ocean: 'light', 'midnight-teal': 'dark', cyber: 'dark', 'cosmic-aurora': 'dark'
  };
  var THEME_LABELS = {
    light: 'Light', dark: 'Dark', obsidian: 'Obsidian', vercel: 'Vercel Black', 'deep-space': 'Deep Space', netflix: 'Netflix Red',
    microsoft: 'Microsoft Fluent', google: 'Google Material 3', apple: 'Apple SF', vscode: 'VSCode Dark', aws: 'AWS Orange', royal: 'Royal',
    spotify: 'Spotify Green', figma: 'Figma Purple', slack: 'Slack Sidebar', airbnb: 'Airbnb Pink', uber: 'Uber Black', sapphire: 'Sapphire Glass',
    nebula: 'Nebula', aurora: 'Aurora', phoenix: 'Phoenix', sakura: 'Sakura', sunset: 'Sunset', rose: 'Rose', slate: 'Slate', emerald: 'Emerald',
    ocean: 'Ocean', 'midnight-teal': 'Midnight Teal', cyber: 'Cyber', 'cosmic-aurora': 'Cosmic Aurora'
  };

  function ready(callback) {
    if (document.readyState !== 'loading') callback();
    else document.addEventListener('DOMContentLoaded', callback, { once: true });
  }

  function qs(selector, scope) {
    return (scope || document).querySelector(selector);
  }

  function qsa(selector, scope) {
    return Array.prototype.slice.call((scope || document).querySelectorAll(selector));
  }

  function storageGet(key) {
    try { return window.localStorage.getItem(key); } catch (_) { return null; }
  }

  function storageSet(key, value) {
    try { window.localStorage.setItem(key, value); } catch (_) {}
  }

  function hasTheme(themeName) {
    return Object.prototype.hasOwnProperty.call(THEME_MODES, themeName);
  }

  function getAccentColor() {
    return getComputedStyle(root).getPropertyValue('--t-accent').trim() || '#38bdf8';
  }

  function getCurrentBasePath() {
    return window.__aetherBase || '';
  }

  function normalizePath(path) {
    if (!path) return '';
    var anchor = document.createElement('a');
    anchor.href = path;
    return anchor.pathname.replace(/\/index\.html$/, '/').replace(/\/+/g, '/').toLowerCase();
  }

  function setTheme(themeName, persist) {
    if (!hasTheme(themeName)) return;
    var mode = THEME_MODES[themeName];
    root.setAttribute('data-theme', themeName);
    root.setAttribute('data-bs-theme', mode);
    root.style.colorScheme = mode;

    if (persist !== false) {
      storageSet('aether-theme', themeName);
      storageSet('uttam-theme', themeName);
    }

    qsa('.theme-swatch[data-theme]').forEach(function (button) {
      var isActive = button.dataset.theme === themeName;
      button.classList.toggle('is-active', isActive);
      button.classList.toggle('active', isActive);
      button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
    });

    var label = qs('#themePreviewLabel');
    if (label) label.textContent = THEME_LABELS[themeName] || themeName;

    var meta = qs('#metaThemeColor');
    if (meta) window.requestAnimationFrame(function () { meta.setAttribute('content', getAccentColor()); });

    qsa('.js-theme-avatar[data-avatar-name]').forEach(function (img) {
      var color = getAccentColor().replace('#', '') || '38bdf8';
      var name = img.dataset.avatarName || 'Aether Admin';
      img.src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(name) + '&background=' + color + '&color=0f172a&bold=true&size=34';
    });
  }

  function initTheme() {
    var saved = storageGet('aether-theme') || storageGet('uttam-theme');
    var htmlTheme = root.getAttribute('data-theme');
    var initial = hasTheme(saved) ? saved : (hasTheme(htmlTheme) ? htmlTheme : 'light');
    setTheme(initial, false);

    qsa('.theme-swatch[data-theme]').forEach(function (button) {
      button.addEventListener('click', function () {
        setTheme(button.dataset.theme, true);
      });
      button.addEventListener('mouseenter', function () {
        var label = qs('#themePreviewLabel');
        if (label) label.textContent = button.title || THEME_LABELS[button.dataset.theme] || button.dataset.theme;
      });
    });

    var themeSearch = qs('#themeSearch');
    var noResults = qs('#themeNoResults');
    if (!themeSearch) return;

    themeSearch.addEventListener('input', function () {
      var query = themeSearch.value.trim().toLowerCase();
      var visibleCount = 0;

      qsa('.theme-swatch[data-theme]').forEach(function (button) {
        var searchable = [button.title, button.dataset.theme, THEME_LABELS[button.dataset.theme]].join(' ').toLowerCase();
        var isVisible = !query || searchable.indexOf(query) !== -1;
        button.hidden = !isVisible;
        if (isVisible) visibleCount += 1;
      });

      qsa('.theme-grid').forEach(function (grid) {
        grid.hidden = !qsa('.theme-swatch[data-theme]', grid).some(function (button) { return !button.hidden; });
      });

      qsa('.theme-group-label').forEach(function (label) {
        var grid = label.nextElementSibling;
        label.hidden = !!(grid && grid.classList.contains('theme-grid') && grid.hidden);
      });

      if (noResults) noResults.hidden = visibleCount > 0;
    });
  }

  function initSidebar() {
    var wrapper = qs('#adminWrapper') || qs('.admin-wrapper');
    var sidebar = qs('#sidebar') || qs('.admin-sidebar');
    var toggles = qsa('#sidebarCollapse, [data-sidebar-toggle]');
    var overlay = qs('#sidebarOverlay') || qs('.sidebar-overlay');
    var desktopQuery = window.matchMedia('(min-width: 768px)');
    var storageKey = 'aether-sidebar-state';

    function isDesktop() {
      return desktopQuery.matches;
    }

    function setDesktopCollapsed(collapsed, persist) {
      if (!wrapper) return;

      wrapper.classList.toggle('sidebar-collapsed', collapsed);
      wrapper.classList.remove('sidebar-mini');
      document.body.classList.toggle('sidebar-collapsed', collapsed);
      document.body.classList.remove('sidebar-mini');

      toggles.forEach(function (button) {
        button.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        button.setAttribute('aria-label', collapsed ? 'Expand sidebar' : 'Collapse sidebar');
      });

      if (persist !== false) storageSet(storageKey, collapsed ? 'collapsed' : 'expanded');
    }

    function openMobileSidebar() {
      if (!sidebar) return;
      sidebar.classList.add('sidebar-open', 'active');
      if (overlay) overlay.classList.add('active');
      toggles.forEach(function (button) { button.setAttribute('aria-expanded', 'true'); });
      document.body.style.overflow = 'hidden';
    }

    function closeMobileSidebar() {
      if (sidebar) sidebar.classList.remove('sidebar-open', 'active');
      if (overlay) overlay.classList.remove('active');
      toggles.forEach(function (button) { button.setAttribute('aria-expanded', 'false'); });
      document.body.style.overflow = '';
    }

    function syncLayoutFromViewport() {
      if (isDesktop()) {
        closeMobileSidebar();
        var saved = storageGet(storageKey) || storageGet('aether-sidebar-mode');
        setDesktopCollapsed(saved === 'collapsed' || saved === 'mini', false);
      } else {
        if (wrapper) {
          wrapper.classList.remove('sidebar-collapsed', 'sidebar-mini');
          document.body.classList.remove('sidebar-collapsed', 'sidebar-mini');
        }
        closeMobileSidebar();
      }
    }

    toggles.forEach(function (button) {
      button.addEventListener('click', function () {
        if (isDesktop()) {
          var collapsed = wrapper ? !wrapper.classList.contains('sidebar-collapsed') : false;
          setDesktopCollapsed(collapsed, true);
        } else if (sidebar && (sidebar.classList.contains('sidebar-open') || sidebar.classList.contains('active'))) {
          closeMobileSidebar();
        } else {
          openMobileSidebar();
        }
      });
    });

    if (overlay) overlay.addEventListener('click', closeMobileSidebar);

    qsa('.admin-sidebar__nav a.nav-link, .sidebarnav a.nav-link').forEach(function (link) {
      link.addEventListener('click', function () {
        if (!isDesktop()) closeMobileSidebar();
      });
    });

    if (desktopQuery.addEventListener) desktopQuery.addEventListener('change', syncLayoutFromViewport);
    else if (desktopQuery.addListener) desktopQuery.addListener(syncLayoutFromViewport);

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') closeMobileSidebar();
    });

    syncLayoutFromViewport();
  }

  function initActiveNavigation() {
    var currentPath = normalizePath(window.location.href);
    var currentFile = (window.location.pathname.split('/').pop() || 'dashboard.html').toLowerCase();

    qsa('.admin-sidebar__nav a.nav-link[href], .sidebarnav a.nav-link[href]').forEach(function (link) {
      var href = link.getAttribute('href') || '';
      if (!href || href === '#') return;

      var linkPath = normalizePath(href);
      var linkFile = href.split('/').pop().toLowerCase();
      var isActive = currentPath === linkPath || currentFile === linkFile;

      if (isActive) {
        link.classList.add('active');
        link.setAttribute('aria-current', 'page');
        var collapse = link.closest('.collapse');
        if (collapse) {
          collapse.classList.add('show');
          var trigger = qs('[data-bs-target="#' + collapse.id + '"]');
          if (trigger) {
            trigger.classList.add('active');
            trigger.setAttribute('aria-expanded', 'true');
          }
        }
      }
    });
  }

  function initHeader() {
    var header = qs('.admin-header');
    if (!header) return;
    function update() {
      header.classList.toggle('is-scrolled', window.scrollY > 8);
    }
    update();
    window.addEventListener('scroll', update, { passive: true });
  }

  function buildCommandItems() {
    var seen = Object.create(null);
    return qsa('.admin-sidebar__nav a.nav-link[href], .sidebarnav a.nav-link[href]').map(function (link) {
      var text = link.textContent.replace(/\s+/g, ' ').trim();
      var href = link.getAttribute('href');
      var icon = qs('i:first-child', link);
      var iconClass = icon ? Array.prototype.slice.call(icon.classList).filter(function (name) { return name.indexOf('bi-') === 0; })[0] : 'bi-arrow-right';
      return { text: text, href: href, icon: iconClass || 'bi-arrow-right' };
    }).filter(function (item) {
      if (!item.text || !item.href || item.href === '#') return false;
      var key = item.text + '|' + item.href;
      if (seen[key]) return false;
      seen[key] = true;
      return true;
    });
  }

  function initCommandPalette() {
    var backdrop = qs('#commandPaletteBackdrop');
    var input = qs('#commandPaletteInput');
    var list = qs('#commandPaletteList');
    var headerSearch = qs('#globalSearchInput');
    if (!backdrop || !input || !list) return;

    var items = buildCommandItems();

    function render(query) {
      var q = String(query || '').trim().toLowerCase();
      var matches = items.filter(function (item) { return !q || item.text.toLowerCase().indexOf(q) !== -1; }).slice(0, 24);
      list.innerHTML = matches.map(function (item, index) {
        return '<button type="button" class="command-palette__item' + (index === 0 ? ' is-active' : '') + '" data-href="' + escapeAttribute(item.href) + '">' +
          '<i class="bi ' + escapeAttribute(item.icon) + '" aria-hidden="true"></i><span>' + escapeHtml(item.text) + '</span></button>';
      }).join('') || '<div class="command-palette__item text-muted" aria-disabled="true">No matching pages found.</div>';
    }

    function open() {
      render(input.value);
      backdrop.classList.add('show');
      backdrop.setAttribute('aria-hidden', 'false');
      window.setTimeout(function () { input.focus(); input.select(); }, 25);
    }

    function close() {
      backdrop.classList.remove('show');
      backdrop.setAttribute('aria-hidden', 'true');
      input.value = '';
    }

    function goToActive() {
      var active = qs('.command-palette__item.is-active[data-href]', list) || qs('.command-palette__item[data-href]', list);
      if (active) window.location.href = active.dataset.href;
    }

    input.addEventListener('input', function () { render(input.value); });
    input.addEventListener('keydown', function (event) {
      var buttons = qsa('.command-palette__item[data-href]', list);
      var index = buttons.findIndex(function (button) { return button.classList.contains('is-active'); });
      if (event.key === 'ArrowDown') {
        event.preventDefault();
        if (buttons.length) {
          buttons.forEach(function (button) { button.classList.remove('is-active'); });
          buttons[(index + 1 + buttons.length) % buttons.length].classList.add('is-active');
        }
      }
      if (event.key === 'ArrowUp') {
        event.preventDefault();
        if (buttons.length) {
          buttons.forEach(function (button) { button.classList.remove('is-active'); });
          buttons[(index - 1 + buttons.length) % buttons.length].classList.add('is-active');
        }
      }
      if (event.key === 'Enter') {
        event.preventDefault();
        goToActive();
      }
      if (event.key === 'Escape') close();
    });

    list.addEventListener('click', function (event) {
      var button = event.target.closest('.command-palette__item[data-href]');
      if (button) window.location.href = button.dataset.href;
    });

    backdrop.addEventListener('click', function (event) {
      if (event.target === backdrop) close();
    });

    document.addEventListener('keydown', function (event) {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        open();
      }
      if (event.key === 'Escape' && backdrop.classList.contains('show')) close();
    });

    if (headerSearch) {
      headerSearch.addEventListener('focus', open);
      headerSearch.addEventListener('click', open);
    }
  }

  function showToast(message) {
    if (!message) return;
    var toast = qs('.aether-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'aether-toast';
      toast.setAttribute('role', 'status');
      toast.setAttribute('aria-live', 'polite');
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('is-visible');
    window.clearTimeout(window.__aetherToastTimer);
    window.__aetherToastTimer = window.setTimeout(function () { toast.classList.remove('is-visible'); }, 2200);
  }

  function initDelegatedActions() {
    document.addEventListener('click', function (event) {
      var toastButton = event.target.closest('[data-toast]');
      if (toastButton) showToast(toastButton.getAttribute('data-toast') || 'Action completed');

      var logoutButton = event.target.closest('.js-logout');
      if (logoutButton) {
        if (window.confirm('Are you sure you want to log out?')) window.location.href = getCurrentBasePath() + 'auth/login.html';
      }

      var quantityButton = event.target.closest('.quantity button');
      if (quantityButton) {
        var box = quantityButton.parentElement;
        var valueNode = box ? qs('span', box) : null;
        if (!valueNode) return;
        var value = parseInt(valueNode.textContent, 10) || 1;
        if (quantityButton.textContent.trim() === '+') value += 1;
        if (quantityButton.textContent.trim() === '-') value = Math.max(1, value - 1);
        valueNode.textContent = String(value);
      }
    });
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"]/g, function (char) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[char];
    });
  }

  function escapeAttribute(value) {
    return escapeHtml(value).replace(/'/g, '&#39;');
  }

  ready(function () {
    initTheme();
    initSidebar();
    initActiveNavigation();
    initHeader();
    initCommandPalette();
    initDelegatedActions();
  });
})();
