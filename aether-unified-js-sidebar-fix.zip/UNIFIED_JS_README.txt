Aether unified JavaScript groups
================================

Files generated:
- aether-dashboard.bundle.js  -> load on dashboard/admin pages only.
- aether-auth.bundle.js       -> load on auth and utility pages only.
- app.css                     -> same app CSS with a final sidebar collapse safety patch.
- dashboard.updated.html      -> example dashboard page using the dashboard bundle.

Recommended dashboard load order:
1. bootstrap.bundle.min.js
2. assets/js/aether-dashboard.bundle.js

Recommended auth/utility load order:
1. bootstrap.bundle.min.js, if the page uses Bootstrap JS widgets
2. assets/js/aether-auth.bundle.js

Do not also load these older standalone files on the same page:
- theme-switcher.js
- theme-boot.js
- auth.js
- auth-pages.js
- auth-demo.js
- dashboard.js
- aether-polish.js

Sidebar fix:
- Desktop toggle now uses one canonical state: .sidebar-collapsed.
- Desktop collapsed state shrinks the sidebar to --auk-sidebar-mini-width, default 80px.
- Mobile behavior remains offcanvas with .sidebar-open / .active.
